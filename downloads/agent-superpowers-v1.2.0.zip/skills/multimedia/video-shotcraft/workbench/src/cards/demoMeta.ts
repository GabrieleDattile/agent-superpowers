// 自动生成，勿手改：node scripts/gen-index.mjs
// demo 组件名 → 中文名 / 所属镜头卡 / 画廊分类 / 预览视频（gallery/media 本地已拉取时）/ 一句话
export type DemoMeta = { name: string; nameEn: string; card: string; category: string; categoryKey: string; styleKey?: string; preview?: string; summary?: string; summaryEn?: string };
export const DEMO_META: Record<string, DemoMeta> = {
  "Basic3DScene": {
    "name": "undefined · Basic3DScene",
    "nameEn": "undefined · Basic3DScene",
    "category": "camera\\basic-3d-scene\\Basic3DScene",
    "categoryKey": "camera\\basic-3d-scene\\Basic3DScene"
  },
  "CrashImpactReal": {
    "name": "undefined · CrashImpactReal",
    "nameEn": "undefined · CrashImpactReal",
    "category": "camera\\crash-zoom-punch\\CrashImpactReal",
    "categoryKey": "camera\\crash-zoom-punch\\CrashImpactReal"
  },
  "CrashZoomReal": {
    "name": "undefined · CrashZoomReal",
    "nameEn": "undefined · CrashZoomReal",
    "category": "camera\\crash-zoom-punch\\CrashZoomReal",
    "categoryKey": "camera\\crash-zoom-punch\\CrashZoomReal"
  },
  "CursorFlyover": {
    "name": "undefined · CursorFlyover",
    "nameEn": "undefined · CursorFlyover",
    "category": "camera\\cursor-flyover\\CursorFlyover",
    "categoryKey": "camera\\cursor-flyover\\CursorFlyover"
  },
  "DollyZoomReal": {
    "name": "undefined · DollyZoomReal",
    "nameEn": "undefined · DollyZoomReal",
    "category": "camera\\depth-layer-moves\\DollyZoomReal",
    "categoryKey": "camera\\depth-layer-moves\\DollyZoomReal"
  },
  "MultiplaneReal": {
    "name": "undefined · MultiplaneReal",
    "nameEn": "undefined · MultiplaneReal",
    "category": "camera\\depth-layer-moves\\MultiplaneReal",
    "categoryKey": "camera\\depth-layer-moves\\MultiplaneReal"
  },
  "GrazeFaceTour": {
    "name": "undefined · GrazeFaceTour",
    "nameEn": "undefined · GrazeFaceTour",
    "category": "camera\\graze-face-tour\\GrazeFaceTour",
    "categoryKey": "camera\\graze-face-tour\\GrazeFaceTour"
  },
  "OverheadTabletopDrop": {
    "name": "undefined · OverheadTabletopDrop",
    "nameEn": "undefined · OverheadTabletopDrop",
    "category": "camera\\overhead-camera-moves\\OverheadTabletopDrop",
    "categoryKey": "camera\\overhead-camera-moves\\OverheadTabletopDrop"
  },
  "TiltReveal": {
    "name": "undefined · TiltReveal",
    "nameEn": "undefined · TiltReveal",
    "category": "camera\\overhead-camera-moves\\TiltReveal",
    "categoryKey": "camera\\overhead-camera-moves\\TiltReveal"
  },
  "DroneDiveLanding": {
    "name": "undefined · DroneDiveLanding",
    "nameEn": "undefined · DroneDiveLanding",
    "category": "camera\\space-camera-moves\\DroneDiveLanding",
    "categoryKey": "camera\\space-camera-moves\\DroneDiveLanding"
  },
  "ExplodedView": {
    "name": "undefined · ExplodedView",
    "nameEn": "undefined · ExplodedView",
    "category": "camera\\space-camera-moves\\ExplodedView",
    "categoryKey": "camera\\space-camera-moves\\ExplodedView"
  },
  "SteepTiltGlide": {
    "name": "undefined · SteepTiltGlide",
    "nameEn": "undefined · SteepTiltGlide",
    "category": "camera\\steep-tilt-glide\\SteepTiltGlide",
    "categoryKey": "camera\\steep-tilt-glide\\SteepTiltGlide"
  },
  "BulletTimeFreezeOrbit": {
    "name": "undefined · BulletTimeFreezeOrbit",
    "nameEn": "undefined · BulletTimeFreezeOrbit",
    "category": "camera\\tension-camera-moves\\BulletTimeFreezeOrbit",
    "categoryKey": "camera\\tension-camera-moves\\BulletTimeFreezeOrbit"
  },
  "DutchRollToLevel": {
    "name": "undefined · DutchRollToLevel",
    "nameEn": "undefined · DutchRollToLevel",
    "category": "camera\\tension-camera-moves\\DutchRollToLevel",
    "categoryKey": "camera\\tension-camera-moves\\DutchRollToLevel"
  },
  "PullBackIsolation": {
    "name": "undefined · PullBackIsolation",
    "nameEn": "undefined · PullBackIsolation",
    "category": "camera\\tension-camera-moves\\PullBackIsolation",
    "categoryKey": "camera\\tension-camera-moves\\PullBackIsolation"
  },
  "SlowPushIn": {
    "name": "undefined · SlowPushIn",
    "nameEn": "undefined · SlowPushIn",
    "category": "camera\\tension-camera-moves\\SlowPushIn",
    "categoryKey": "camera\\tension-camera-moves\\SlowPushIn"
  },
  "Terminal3D": {
    "name": "undefined · Terminal3D",
    "nameEn": "undefined · Terminal3D",
    "category": "camera\\terminal-3d\\Terminal3D",
    "categoryKey": "camera\\terminal-3d\\Terminal3D"
  },
  "AvatarGridRadialBuildColorize": {
    "name": "undefined · AvatarGridRadialBuildColorize",
    "nameEn": "undefined · AvatarGridRadialBuildColorize",
    "category": "data\\avatar-grid-radial-build-colorize\\AvatarGridRadialBuildColorize",
    "categoryKey": "data\\avatar-grid-radial-build-colorize\\AvatarGridRadialBuildColorize"
  },
  "BeforeAfterSliderScrub": {
    "name": "undefined · BeforeAfterSliderScrub",
    "nameEn": "undefined · BeforeAfterSliderScrub",
    "category": "data\\before-after-slider-scrub\\BeforeAfterSliderScrub",
    "categoryKey": "data\\before-after-slider-scrub\\BeforeAfterSliderScrub"
  },
  "AxisRescaleShockV2": {
    "name": "undefined · AxisRescaleShockV2",
    "nameEn": "undefined · AxisRescaleShockV2",
    "category": "data\\chart-live-moves\\AxisRescaleShockV2",
    "categoryKey": "data\\chart-live-moves\\AxisRescaleShockV2"
  },
  "OscilloscopeStreamV2": {
    "name": "undefined · OscilloscopeStreamV2",
    "nameEn": "undefined · OscilloscopeStreamV2",
    "category": "data\\chart-live-moves\\OscilloscopeStreamV2",
    "categoryKey": "data\\chart-live-moves\\OscilloscopeStreamV2"
  },
  "UnitDotSwarmRegroupV2": {
    "name": "undefined · UnitDotSwarmRegroupV2",
    "nameEn": "undefined · UnitDotSwarmRegroupV2",
    "category": "data\\chart-live-moves\\UnitDotSwarmRegroupV2",
    "categoryKey": "data\\chart-live-moves\\UnitDotSwarmRegroupV2"
  },
  "CounterConfetti": {
    "name": "undefined · CounterConfetti",
    "nameEn": "undefined · CounterConfetti",
    "category": "data\\counter-confetti\\CounterConfetti",
    "categoryKey": "data\\counter-confetti\\CounterConfetti"
  },
  "CycleGlassNodeMorph": {
    "name": "undefined · CycleGlassNodeMorph",
    "nameEn": "undefined · CycleGlassNodeMorph",
    "category": "data\\cycle-glass-node-morph\\CycleGlassNodeMorph",
    "categoryKey": "data\\cycle-glass-node-morph\\CycleGlassNodeMorph"
  },
  "NeedleSweepSelftest": {
    "name": "undefined · NeedleSweepSelftest",
    "nameEn": "undefined · NeedleSweepSelftest",
    "category": "data\\gauge-readout-moves\\NeedleSweepSelftest",
    "categoryKey": "data\\gauge-readout-moves\\NeedleSweepSelftest"
  },
  "TapeScrollFixedPointer": {
    "name": "undefined · TapeScrollFixedPointer",
    "nameEn": "undefined · TapeScrollFixedPointer",
    "category": "data\\gauge-readout-moves\\TapeScrollFixedPointer",
    "categoryKey": "data\\gauge-readout-moves\\TapeScrollFixedPointer"
  },
  "HatchDepth": {
    "name": "undefined · HatchDepth",
    "nameEn": "undefined · HatchDepth",
    "category": "data\\hatch-depth\\HatchDepth",
    "categoryKey": "data\\hatch-depth\\HatchDepth"
  },
  "OdometerDigitRoll": {
    "name": "undefined · OdometerDigitRoll",
    "nameEn": "undefined · OdometerDigitRoll",
    "category": "data\\odometer-digit-roll\\OdometerDigitRoll",
    "categoryKey": "data\\odometer-digit-roll\\OdometerDigitRoll"
  },
  "ConfettiCrossfire": {
    "name": "undefined · ConfettiCrossfire",
    "nameEn": "undefined · ConfettiCrossfire",
    "category": "data\\particle-celebrate-hits\\ConfettiCrossfire",
    "categoryKey": "data\\particle-celebrate-hits\\ConfettiCrossfire"
  },
  "CounterTickSparks": {
    "name": "undefined · CounterTickSparks",
    "nameEn": "undefined · CounterTickSparks",
    "category": "data\\particle-celebrate-hits\\CounterTickSparks",
    "categoryKey": "data\\particle-celebrate-hits\\CounterTickSparks"
  },
  "ParticleSandFill": {
    "name": "undefined · ParticleSandFill",
    "nameEn": "undefined · ParticleSandFill",
    "category": "data\\particle-sand-fill\\ParticleSandFill",
    "categoryKey": "data\\particle-sand-fill\\ParticleSandFill"
  },
  "RingDiagramAnnotationReveal": {
    "name": "undefined · RingDiagramAnnotationReveal",
    "nameEn": "undefined · RingDiagramAnnotationReveal",
    "category": "data\\ring-diagram-annotation-reveal\\RingDiagramAnnotationReveal",
    "categoryKey": "data\\ring-diagram-annotation-reveal\\RingDiagramAnnotationReveal"
  },
  "BrakeReticleLock": {
    "name": "undefined · BrakeReticleLock",
    "nameEn": "undefined · BrakeReticleLock",
    "category": "data\\scroll-brake-moves\\BrakeReticleLock",
    "categoryKey": "data\\scroll-brake-moves\\BrakeReticleLock"
  },
  "ChangelogScrollBrake": {
    "name": "undefined · ChangelogScrollBrake",
    "nameEn": "undefined · ChangelogScrollBrake",
    "category": "data\\scroll-brake-moves\\ChangelogScrollBrake",
    "categoryKey": "data\\scroll-brake-moves\\ChangelogScrollBrake"
  },
  "TimelineTravel": {
    "name": "undefined · TimelineTravel",
    "nameEn": "undefined · TimelineTravel",
    "category": "data\\timeline-travel\\TimelineTravel",
    "categoryKey": "data\\timeline-travel\\TimelineTravel"
  },
  "AssembleThenTypeFlyin": {
    "name": "undefined · AssembleThenTypeFlyin",
    "nameEn": "undefined · AssembleThenTypeFlyin",
    "category": "effects\\assemble-then-type-flyin\\AssembleThenTypeFlyin",
    "categoryKey": "effects\\assemble-then-type-flyin\\AssembleThenTypeFlyin"
  },
  "AuroraBloomBgFlip": {
    "name": "undefined · AuroraBloomBgFlip",
    "nameEn": "undefined · AuroraBloomBgFlip",
    "category": "effects\\aurora-bloom-bg-flip\\AuroraBloomBgFlip",
    "categoryKey": "effects\\aurora-bloom-bg-flip\\AuroraBloomBgFlip"
  },
  "BrandFrameSnap": {
    "name": "undefined · BrandFrameSnap",
    "nameEn": "undefined · BrandFrameSnap",
    "category": "effects\\brand-frame-snap\\BrandFrameSnap",
    "categoryKey": "effects\\brand-frame-snap\\BrandFrameSnap"
  },
  "DashboardGlowHighlightPill": {
    "name": "undefined · DashboardGlowHighlightPill",
    "nameEn": "undefined · DashboardGlowHighlightPill",
    "category": "effects\\dashboard-glow-highlight-pill\\DashboardGlowHighlightPill",
    "categoryKey": "effects\\dashboard-glow-highlight-pill\\DashboardGlowHighlightPill"
  },
  "LineUnfoldPanel": {
    "name": "undefined · LineUnfoldPanel",
    "nameEn": "undefined · LineUnfoldPanel",
    "category": "effects\\fui-hud-moves\\LineUnfoldPanel",
    "categoryKey": "effects\\fui-hud-moves\\LineUnfoldPanel"
  },
  "ReticleLockOn": {
    "name": "undefined · ReticleLockOn",
    "nameEn": "undefined · ReticleLockOn",
    "category": "effects\\fui-hud-moves\\ReticleLockOn",
    "categoryKey": "effects\\fui-hud-moves\\ReticleLockOn"
  },
  "FlylineArc": {
    "name": "undefined · FlylineArc",
    "nameEn": "undefined · FlylineArc",
    "category": "effects\\glow-flyline-moves\\FlylineArc",
    "categoryKey": "effects\\glow-flyline-moves\\FlylineArc"
  },
  "GlowOrbAmbient": {
    "name": "undefined · GlowOrbAmbient",
    "nameEn": "undefined · GlowOrbAmbient",
    "category": "effects\\glow-flyline-moves\\GlowOrbAmbient",
    "categoryKey": "effects\\glow-flyline-moves\\GlowOrbAmbient"
  },
  "OrbFlylineRelay": {
    "name": "undefined · OrbFlylineRelay",
    "nameEn": "undefined · OrbFlylineRelay",
    "category": "effects\\glow-flyline-moves\\OrbFlylineRelay",
    "categoryKey": "effects\\glow-flyline-moves\\OrbFlylineRelay"
  },
  "AttentionBounce": {
    "name": "undefined · AttentionBounce",
    "nameEn": "undefined · AttentionBounce",
    "category": "effects\\icon-performance-moves\\AttentionBounce",
    "categoryKey": "effects\\icon-performance-moves\\AttentionBounce"
  },
  "PopBurstConfirm": {
    "name": "undefined · PopBurstConfirm",
    "nameEn": "undefined · PopBurstConfirm",
    "category": "effects\\icon-performance-moves\\PopBurstConfirm",
    "categoryKey": "effects\\icon-performance-moves\\PopBurstConfirm"
  },
  "AnimeImpact": {
    "name": "undefined · AnimeImpact",
    "nameEn": "undefined · AnimeImpact",
    "category": "effects\\impact-feedback\\AnimeImpact",
    "categoryKey": "effects\\impact-feedback\\AnimeImpact"
  },
  "HitCounter": {
    "name": "undefined · HitCounter",
    "nameEn": "undefined · HitCounter",
    "category": "effects\\impact-feedback\\HitCounter",
    "categoryKey": "effects\\impact-feedback\\HitCounter"
  },
  "HalationBloom": {
    "name": "undefined · HalationBloom",
    "nameEn": "undefined · HalationBloom",
    "category": "effects\\light-play-moves\\HalationBloom",
    "categoryKey": "effects\\light-play-moves\\HalationBloom"
  },
  "SheenSweepRetry": {
    "name": "undefined · SheenSweepRetry",
    "nameEn": "undefined · SheenSweepRetry",
    "category": "effects\\light-play-moves\\SheenSweepRetry",
    "categoryKey": "effects\\light-play-moves\\SheenSweepRetry"
  },
  "SpotlightSweepReveal": {
    "name": "undefined · SpotlightSweepReveal",
    "nameEn": "undefined · SpotlightSweepReveal",
    "category": "effects\\light-play-moves\\SpotlightSweepReveal",
    "categoryKey": "effects\\light-play-moves\\SpotlightSweepReveal"
  },
  "LineBoil": {
    "name": "undefined · LineBoil",
    "nameEn": "undefined · LineBoil",
    "category": "effects\\line-boil\\LineBoil",
    "categoryKey": "effects\\line-boil\\LineBoil"
  },
  "RadialRipplePhoneChips": {
    "name": "undefined · RadialRipplePhoneChips",
    "nameEn": "undefined · RadialRipplePhoneChips",
    "category": "effects\\radial-ripple-phone-chips\\RadialRipplePhoneChips",
    "categoryKey": "effects\\radial-ripple-phone-chips\\RadialRipplePhoneChips"
  },
  "RisoBeatPump": {
    "name": "undefined · RisoBeatPump",
    "nameEn": "undefined · RisoBeatPump",
    "category": "effects\\riso-print-hits\\RisoBeatPump",
    "categoryKey": "effects\\riso-print-hits\\RisoBeatPump"
  },
  "RisoMisregistrationHit": {
    "name": "undefined · RisoMisregistrationHit",
    "nameEn": "undefined · RisoMisregistrationHit",
    "category": "effects\\riso-print-hits\\RisoMisregistrationHit",
    "categoryKey": "effects\\riso-print-hits\\RisoMisregistrationHit"
  },
  "ScanBracketSweep": {
    "name": "undefined · ScanBracketSweep",
    "nameEn": "undefined · ScanBracketSweep",
    "category": "effects\\scan-bracket-sweep\\ScanBracketSweep",
    "categoryKey": "effects\\scan-bracket-sweep\\ScanBracketSweep"
  },
  "ScanlineAnnotateFocus": {
    "name": "undefined · ScanlineAnnotateFocus",
    "nameEn": "undefined · ScanlineAnnotateFocus",
    "category": "effects\\scanline-annotate-focus\\ScanlineAnnotateFocus",
    "categoryKey": "effects\\scanline-annotate-focus\\ScanlineAnnotateFocus"
  },
  "ScanlineAssembleFlyin": {
    "name": "undefined · ScanlineAssembleFlyin",
    "nameEn": "undefined · ScanlineAssembleFlyin",
    "category": "effects\\scanline-assemble-flyin\\ScanlineAssembleFlyin",
    "categoryKey": "effects\\scanline-assemble-flyin\\ScanlineAssembleFlyin"
  },
  "ImpactBurstKit": {
    "name": "undefined · ImpactBurstKit",
    "nameEn": "undefined · ImpactBurstKit",
    "category": "effects\\slam-entrance-moves\\ImpactBurstKit",
    "categoryKey": "effects\\slam-entrance-moves\\ImpactBurstKit"
  },
  "KanadaPerspectiveSnap": {
    "name": "undefined · KanadaPerspectiveSnap",
    "nameEn": "undefined · KanadaPerspectiveSnap",
    "category": "effects\\slam-entrance-moves\\KanadaPerspectiveSnap",
    "categoryKey": "effects\\slam-entrance-moves\\KanadaPerspectiveSnap"
  },
  "ScoreSlam": {
    "name": "undefined · ScoreSlam",
    "nameEn": "undefined · ScoreSlam",
    "category": "effects\\slam-entrance-moves\\ScoreSlam",
    "categoryKey": "effects\\slam-entrance-moves\\ScoreSlam"
  },
  "CornerSpotlightReveal": {
    "name": "undefined · CornerSpotlightReveal",
    "nameEn": "undefined · CornerSpotlightReveal",
    "category": "effects\\spotlight-sweep-moves\\CornerSpotlightReveal",
    "categoryKey": "effects\\spotlight-sweep-moves\\CornerSpotlightReveal"
  },
  "GlowWakeSleepPanel": {
    "name": "undefined · GlowWakeSleepPanel",
    "nameEn": "undefined · GlowWakeSleepPanel",
    "category": "effects\\spotlight-sweep-moves\\GlowWakeSleepPanel",
    "categoryKey": "effects\\spotlight-sweep-moves\\GlowWakeSleepPanel"
  },
  "SlideSpotlightPan": {
    "name": "undefined · SlideSpotlightPan",
    "nameEn": "undefined · SlideSpotlightPan",
    "category": "effects\\spotlight-sweep-moves\\SlideSpotlightPan",
    "categoryKey": "effects\\spotlight-sweep-moves\\SlideSpotlightPan"
  },
  "StreamResponse": {
    "name": "undefined · StreamResponse",
    "nameEn": "undefined · StreamResponse",
    "category": "interaction\\ai-stream-response\\StreamResponse",
    "categoryKey": "interaction\\ai-stream-response\\StreamResponse"
  },
  "AutolayoutGapDial": {
    "name": "undefined · AutolayoutGapDial",
    "nameEn": "undefined · AutolayoutGapDial",
    "category": "interaction\\autolayout-gap-dial\\AutolayoutGapDial",
    "categoryKey": "interaction\\autolayout-gap-dial\\AutolayoutGapDial"
  },
  "DiagramCascadeBuild": {
    "name": "undefined · DiagramCascadeBuild",
    "nameEn": "undefined · DiagramCascadeBuild",
    "category": "interaction\\canvas-materialize-moves\\DiagramCascadeBuild",
    "categoryKey": "interaction\\canvas-materialize-moves\\DiagramCascadeBuild"
  },
  "PanelToCanvasMaterialize": {
    "name": "undefined · PanelToCanvasMaterialize",
    "nameEn": "undefined · PanelToCanvasMaterialize",
    "category": "interaction\\canvas-materialize-moves\\PanelToCanvasMaterialize",
    "categoryKey": "interaction\\canvas-materialize-moves\\PanelToCanvasMaterialize"
  },
  "ChipGridSingleSelectBlackout": {
    "name": "undefined · ChipGridSingleSelectBlackout",
    "nameEn": "undefined · ChipGridSingleSelectBlackout",
    "category": "interaction\\chip-grid-single-select-blackout\\ChipGridSingleSelectBlackout",
    "categoryKey": "interaction\\chip-grid-single-select-blackout\\ChipGridSingleSelectBlackout"
  },
  "ChipLiftToUserPill": {
    "name": "undefined · ChipLiftToUserPill",
    "nameEn": "undefined · ChipLiftToUserPill",
    "category": "interaction\\chip-lift-to-user-pill\\ChipLiftToUserPill",
    "categoryKey": "interaction\\chip-lift-to-user-pill\\ChipLiftToUserPill"
  },
  "CursorCastEnsemble": {
    "name": "undefined · CursorCastEnsemble",
    "nameEn": "undefined · CursorCastEnsemble",
    "category": "interaction\\collab-cursor-moves\\CursorCastEnsemble",
    "categoryKey": "interaction\\collab-cursor-moves\\CursorCastEnsemble"
  },
  "CursorDialogueDuet": {
    "name": "undefined · CursorDialogueDuet",
    "nameEn": "undefined · CursorDialogueDuet",
    "category": "interaction\\collab-cursor-moves\\CursorDialogueDuet",
    "categoryKey": "interaction\\collab-cursor-moves\\CursorDialogueDuet"
  },
  "CommandPaletteSummon": {
    "name": "undefined · CommandPaletteSummon",
    "nameEn": "undefined · CommandPaletteSummon",
    "category": "interaction\\command-palette-summon\\CommandPaletteSummon",
    "categoryKey": "interaction\\command-palette-summon\\CommandPaletteSummon"
  },
  "GlassPillDictationTyping": {
    "name": "undefined · GlassPillDictationTyping",
    "nameEn": "undefined · GlassPillDictationTyping",
    "category": "interaction\\glass-pill-dictation-typing\\GlassPillDictationTyping",
    "categoryKey": "interaction\\glass-pill-dictation-typing\\GlassPillDictationTyping"
  },
  "HashtagToPillMaterialize": {
    "name": "undefined · HashtagToPillMaterialize",
    "nameEn": "undefined · HashtagToPillMaterialize",
    "category": "interaction\\hashtag-to-pill-materialize\\HashtagToPillMaterialize",
    "categoryKey": "interaction\\hashtag-to-pill-materialize\\HashtagToPillMaterialize"
  },
  "CursorPerformancePunchIn": {
    "name": "undefined · CursorPerformancePunchIn",
    "nameEn": "undefined · CursorPerformancePunchIn",
    "category": "interaction\\input-trigger-moves\\CursorPerformancePunchIn",
    "categoryKey": "interaction\\input-trigger-moves\\CursorPerformancePunchIn"
  },
  "KeycapSmashCut": {
    "name": "undefined · KeycapSmashCut",
    "nameEn": "undefined · KeycapSmashCut",
    "category": "interaction\\input-trigger-moves\\KeycapSmashCut",
    "categoryKey": "interaction\\input-trigger-moves\\KeycapSmashCut"
  },
  "PickerCarouselFeatureCycle": {
    "name": "undefined · PickerCarouselFeatureCycle",
    "nameEn": "undefined · PickerCarouselFeatureCycle",
    "category": "interaction\\picker-carousel-feature-cycle\\PickerCarouselFeatureCycle",
    "categoryKey": "interaction\\picker-carousel-feature-cycle\\PickerCarouselFeatureCycle"
  },
  "SegmentedThumbHero": {
    "name": "undefined · SegmentedThumbHero",
    "nameEn": "undefined · SegmentedThumbHero",
    "category": "interaction\\segmented-thumb-hero\\SegmentedThumbHero",
    "categoryKey": "interaction\\segmented-thumb-hero\\SegmentedThumbHero"
  },
  "PaletteThemeRipple": {
    "name": "undefined · PaletteThemeRipple",
    "nameEn": "undefined · PaletteThemeRipple",
    "category": "interaction\\theme-switch-moves\\PaletteThemeRipple",
    "categoryKey": "interaction\\theme-switch-moves\\PaletteThemeRipple"
  },
  "ThemeSweepToggle": {
    "name": "undefined · ThemeSweepToggle",
    "nameEn": "undefined · ThemeSweepToggle",
    "category": "interaction\\theme-switch-moves\\ThemeSweepToggle",
    "categoryKey": "interaction\\theme-switch-moves\\ThemeSweepToggle"
  },
  "TypeAndFilter": {
    "name": "undefined · TypeAndFilter",
    "nameEn": "undefined · TypeAndFilter",
    "category": "interaction\\type-and-filter\\TypeAndFilter",
    "categoryKey": "interaction\\type-and-filter\\TypeAndFilter"
  },
  "VoiceWaveformLive": {
    "name": "undefined · VoiceWaveformLive",
    "nameEn": "undefined · VoiceWaveformLive",
    "category": "interaction\\voice-waveform-live\\VoiceWaveformLive",
    "categoryKey": "interaction\\voice-waveform-live\\VoiceWaveformLive"
  },
  "CraneRiseReveal": {
    "name": "undefined · CraneRiseReveal",
    "nameEn": "undefined · CraneRiseReveal",
    "category": "opening\\crane-rise-reveal\\CraneRiseReveal",
    "categoryKey": "opening\\crane-rise-reveal\\CraneRiseReveal"
  },
  "DatavizLandscapeOpen": {
    "name": "undefined · DatavizLandscapeOpen",
    "nameEn": "undefined · DatavizLandscapeOpen",
    "category": "opening\\dataviz-landscape-open\\DatavizLandscapeOpen",
    "categoryKey": "opening\\dataviz-landscape-open\\DatavizLandscapeOpen"
  },
  "Fracture": {
    "name": "undefined · Fracture",
    "nameEn": "undefined · Fracture",
    "category": "opening\\fracture\\Fracture",
    "categoryKey": "opening\\fracture\\Fracture"
  },
  "IconFieldColorize": {
    "name": "undefined · IconFieldColorize",
    "nameEn": "undefined · IconFieldColorize",
    "category": "opening\\icon-field-colorize\\IconFieldColorize",
    "categoryKey": "opening\\icon-field-colorize\\IconFieldColorize"
  },
  "LetterspaceMaterialize": {
    "name": "undefined · LetterspaceMaterialize",
    "nameEn": "undefined · LetterspaceMaterialize",
    "category": "opening\\letterspace-materialize\\LetterspaceMaterialize",
    "categoryKey": "opening\\letterspace-materialize\\LetterspaceMaterialize"
  },
  "MagicianCardFlourish": {
    "name": "undefined · MagicianCardFlourish",
    "nameEn": "undefined · MagicianCardFlourish",
    "category": "opening\\magician-card-flourish\\MagicianCardFlourish",
    "categoryKey": "opening\\magician-card-flourish\\MagicianCardFlourish"
  },
  "OrbitRingTitleOpen": {
    "name": "undefined · OrbitRingTitleOpen",
    "nameEn": "undefined · OrbitRingTitleOpen",
    "category": "opening\\orbit-ring-title-open\\OrbitRingTitleOpen",
    "categoryKey": "opening\\orbit-ring-title-open\\OrbitRingTitleOpen"
  },
  "SpotlightHeroCard": {
    "name": "undefined · SpotlightHeroCard",
    "nameEn": "undefined · SpotlightHeroCard",
    "category": "opening\\spotlight-hero-card\\SpotlightHeroCard",
    "categoryKey": "opening\\spotlight-hero-card\\SpotlightHeroCard"
  },
  "StrokeSegmentBuild": {
    "name": "undefined · StrokeSegmentBuild",
    "nameEn": "undefined · StrokeSegmentBuild",
    "category": "opening\\stroke-segment-build\\StrokeSegmentBuild",
    "categoryKey": "opening\\stroke-segment-build\\StrokeSegmentBuild"
  },
  "TextAsMask": {
    "name": "undefined · TextAsMask",
    "nameEn": "undefined · TextAsMask",
    "category": "opening\\text-as-mask\\TextAsMask",
    "categoryKey": "opening\\text-as-mask\\TextAsMask"
  },
  "LogoStingButton": {
    "name": "undefined · LogoStingButton",
    "nameEn": "undefined · LogoStingButton",
    "category": "outro\\edit-hook-moves\\LogoStingButton",
    "categoryKey": "outro\\edit-hook-moves\\LogoStingButton"
  },
  "GrainDissolve": {
    "name": "undefined · GrainDissolve",
    "nameEn": "undefined · GrainDissolve",
    "category": "outro\\grain-dissolve\\GrainDissolve",
    "categoryKey": "outro\\grain-dissolve\\GrainDissolve"
  },
  "LogoShrinkWordmarkLockup": {
    "name": "undefined · LogoShrinkWordmarkLockup",
    "nameEn": "undefined · LogoShrinkWordmarkLockup",
    "category": "outro\\logo-shrink-wordmark-lockup\\LogoShrinkWordmarkLockup",
    "categoryKey": "outro\\logo-shrink-wordmark-lockup\\LogoShrinkWordmarkLockup"
  },
  "NeonTripleMarquee": {
    "name": "undefined · NeonTripleMarquee",
    "nameEn": "undefined · NeonTripleMarquee",
    "category": "outro\\neon-triple-marquee\\NeonTripleMarquee",
    "categoryKey": "outro\\neon-triple-marquee\\NeonTripleMarquee"
  },
  "OutroGroupPhotoLaunch": {
    "name": "undefined · OutroGroupPhotoLaunch",
    "nameEn": "undefined · OutroGroupPhotoLaunch",
    "category": "outro\\outro-group-photo-launch\\OutroGroupPhotoLaunch",
    "categoryKey": "outro\\outro-group-photo-launch\\OutroGroupPhotoLaunch"
  },
  "UiStripAwayOutro": {
    "name": "undefined · UiStripAwayOutro",
    "nameEn": "undefined · UiStripAwayOutro",
    "category": "outro\\ui-strip-away-outro\\UiStripAwayOutro",
    "categoryKey": "outro\\ui-strip-away-outro\\UiStripAwayOutro"
  },
  "IconFlipBloomLogo": {
    "name": "undefined · IconFlipBloomLogo",
    "nameEn": "undefined · IconFlipBloomLogo",
    "category": "outro\\ui-to-brand-morph\\IconFlipBloomLogo",
    "categoryKey": "outro\\ui-to-brand-morph\\IconFlipBloomLogo"
  },
  "InputMorphsIntoLogo": {
    "name": "undefined · InputMorphsIntoLogo",
    "nameEn": "undefined · InputMorphsIntoLogo",
    "category": "outro\\ui-to-brand-morph\\InputMorphsIntoLogo",
    "categoryKey": "outro\\ui-to-brand-morph\\InputMorphsIntoLogo"
  },
  "BeatCutAccelerando": {
    "name": "undefined · BeatCutAccelerando",
    "nameEn": "undefined · BeatCutAccelerando",
    "category": "rhythm\\beat-cut-moves\\BeatCutAccelerando",
    "categoryKey": "rhythm\\beat-cut-moves\\BeatCutAccelerando"
  },
  "PaparazziFlash": {
    "name": "undefined · PaparazziFlash",
    "nameEn": "undefined · PaparazziFlash",
    "category": "rhythm\\beat-cut-moves\\PaparazziFlash",
    "categoryKey": "rhythm\\beat-cut-moves\\PaparazziFlash"
  },
  "BeatStepListThemeCycle": {
    "name": "undefined · BeatStepListThemeCycle",
    "nameEn": "undefined · BeatStepListThemeCycle",
    "category": "rhythm\\beat-step-list-theme-cycle\\BeatStepListThemeCycle",
    "categoryKey": "rhythm\\beat-step-list-theme-cycle\\BeatStepListThemeCycle"
  },
  "DominoCascade": {
    "name": "undefined · DominoCascade",
    "nameEn": "undefined · DominoCascade",
    "category": "rhythm\\montage-rhythm-moves\\DominoCascade",
    "categoryKey": "rhythm\\montage-rhythm-moves\\DominoCascade"
  },
  "DropBlackoutSlam": {
    "name": "undefined · DropBlackoutSlam",
    "nameEn": "undefined · DropBlackoutSlam",
    "category": "rhythm\\montage-rhythm-moves\\DropBlackoutSlam",
    "categoryKey": "rhythm\\montage-rhythm-moves\\DropBlackoutSlam"
  },
  "WrightTripleCut": {
    "name": "undefined · WrightTripleCut",
    "nameEn": "undefined · WrightTripleCut",
    "category": "rhythm\\montage-rhythm-moves\\WrightTripleCut",
    "categoryKey": "rhythm\\montage-rhythm-moves\\WrightTripleCut"
  },
  "ComicPanelSplit": {
    "name": "undefined · ComicPanelSplit",
    "nameEn": "undefined · ComicPanelSplit",
    "category": "rhythm\\panel-grid-moves\\ComicPanelSplit",
    "categoryKey": "rhythm\\panel-grid-moves\\ComicPanelSplit"
  },
  "FlipGridReflow": {
    "name": "undefined · FlipGridReflow",
    "nameEn": "undefined · FlipGridReflow",
    "category": "rhythm\\panel-grid-moves\\FlipGridReflow",
    "categoryKey": "rhythm\\panel-grid-moves\\FlipGridReflow"
  },
  "GridFlashMosaic": {
    "name": "undefined · GridFlashMosaic",
    "nameEn": "undefined · GridFlashMosaic",
    "category": "rhythm\\panel-grid-moves\\GridFlashMosaic",
    "categoryKey": "rhythm\\panel-grid-moves\\GridFlashMosaic"
  },
  "QuadSplitParallelScenes": {
    "name": "undefined · QuadSplitParallelScenes",
    "nameEn": "undefined · QuadSplitParallelScenes",
    "category": "rhythm\\quad-split-parallel-scenes\\QuadSplitParallelScenes",
    "categoryKey": "rhythm\\quad-split-parallel-scenes\\QuadSplitParallelScenes"
  },
  "JumpCutPunchIn": {
    "name": "undefined · JumpCutPunchIn",
    "nameEn": "undefined · JumpCutPunchIn",
    "category": "rhythm\\rhythm-interrupt-moves\\JumpCutPunchIn",
    "categoryKey": "rhythm\\rhythm-interrupt-moves\\JumpCutPunchIn"
  },
  "StrobeBlackFrames": {
    "name": "undefined · StrobeBlackFrames",
    "nameEn": "undefined · StrobeBlackFrames",
    "category": "rhythm\\rhythm-interrupt-moves\\StrobeBlackFrames",
    "categoryKey": "rhythm\\rhythm-interrupt-moves\\StrobeBlackFrames"
  },
  "SakugaTimingShift": {
    "name": "undefined · SakugaTimingShift",
    "nameEn": "undefined · SakugaTimingShift",
    "category": "rhythm\\sakuga-timing-shift\\SakugaTimingShift",
    "categoryKey": "rhythm\\sakuga-timing-shift\\SakugaTimingShift"
  },
  "SmearMultiples": {
    "name": "undefined · SmearMultiples",
    "nameEn": "undefined · SmearMultiples",
    "category": "rhythm\\smear-multiples\\SmearMultiples",
    "categoryKey": "rhythm\\smear-multiples\\SmearMultiples"
  },
  "SpectrumMorphUi": {
    "name": "undefined · SpectrumMorphUi",
    "nameEn": "undefined · SpectrumMorphUi",
    "category": "rhythm\\spectrum-morph-ui\\SpectrumMorphUi",
    "categoryKey": "rhythm\\spectrum-morph-ui\\SpectrumMorphUi"
  },
  "FreezeAnnotateReal": {
    "name": "undefined · FreezeAnnotateReal",
    "nameEn": "undefined · FreezeAnnotateReal",
    "category": "rhythm\\speed-ramp-freeze\\FreezeAnnotateReal",
    "categoryKey": "rhythm\\speed-ramp-freeze\\FreezeAnnotateReal"
  },
  "SpeedRampReal": {
    "name": "undefined · SpeedRampReal",
    "nameEn": "undefined · SpeedRampReal",
    "category": "rhythm\\speed-ramp-freeze\\SpeedRampReal",
    "categoryKey": "rhythm\\speed-ramp-freeze\\SpeedRampReal"
  },
  "CardFootageCadence": {
    "name": "undefined · CardFootageCadence",
    "nameEn": "undefined · CardFootageCadence",
    "category": "rhythm\\trailer-grammar-moves\\CardFootageCadence",
    "categoryKey": "rhythm\\trailer-grammar-moves\\CardFootageCadence"
  },
  "SmashCut": {
    "name": "undefined · SmashCut",
    "nameEn": "undefined · SmashCut",
    "category": "rhythm\\trailer-grammar-moves\\SmashCut",
    "categoryKey": "rhythm\\trailer-grammar-moves\\SmashCut"
  },
  "TrailerBumper": {
    "name": "undefined · TrailerBumper",
    "nameEn": "undefined · TrailerBumper",
    "category": "rhythm\\trailer-grammar-moves\\TrailerBumper",
    "categoryKey": "rhythm\\trailer-grammar-moves\\TrailerBumper"
  },
  "BottomPushStackWipe": {
    "name": "undefined · BottomPushStackWipe",
    "nameEn": "undefined · BottomPushStackWipe",
    "category": "transition\\bottom-push-stack-wipe\\BottomPushStackWipe",
    "categoryKey": "transition\\bottom-push-stack-wipe\\BottomPushStackWipe"
  },
  "BubbleSwarmTakeover": {
    "name": "undefined · BubbleSwarmTakeover",
    "nameEn": "undefined · BubbleSwarmTakeover",
    "category": "transition\\bubble-swarm-takeover\\BubbleSwarmTakeover",
    "categoryKey": "transition\\bubble-swarm-takeover\\BubbleSwarmTakeover"
  },
  "CardFlipReveal": {
    "name": "undefined · CardFlipReveal",
    "nameEn": "undefined · CardFlipReveal",
    "category": "transition\\card-flip-reveal\\CardFlipReveal",
    "categoryKey": "transition\\card-flip-reveal\\CardFlipReveal"
  },
  "CardFlockTumble": {
    "name": "undefined · CardFlockTumble",
    "nameEn": "undefined · CardFlockTumble",
    "category": "transition\\card-flock-tumble\\CardFlockTumble",
    "categoryKey": "transition\\card-flock-tumble\\CardFlockTumble"
  },
  "CircleMatchIris": {
    "name": "undefined · CircleMatchIris",
    "nameEn": "undefined · CircleMatchIris",
    "category": "transition\\circle-match-iris\\CircleMatchIris",
    "categoryKey": "transition\\circle-match-iris\\CircleMatchIris"
  },
  "ColorBlockStepWipe": {
    "name": "undefined · ColorBlockStepWipe",
    "nameEn": "undefined · ColorBlockStepWipe",
    "category": "transition\\color-block-step-wipe\\ColorBlockStepWipe",
    "categoryKey": "transition\\color-block-step-wipe\\ColorBlockStepWipe"
  },
  "CubeNavigation": {
    "name": "undefined · CubeNavigation",
    "nameEn": "undefined · CubeNavigation",
    "category": "transition\\cube-navigation\\CubeNavigation",
    "categoryKey": "transition\\cube-navigation\\CubeNavigation"
  },
  "GradientTransition": {
    "name": "undefined · GradientTransition",
    "nameEn": "undefined · GradientTransition",
    "category": "transition\\gradient-transition\\GradientTransition",
    "categoryKey": "transition\\gradient-transition\\GradientTransition"
  },
  "LineCarryTransition": {
    "name": "undefined · LineCarryTransition",
    "nameEn": "undefined · LineCarryTransition",
    "category": "transition\\line-carry-transition\\LineCarryTransition",
    "categoryKey": "transition\\line-carry-transition\\LineCarryTransition"
  },
  "MosaicReframe": {
    "name": "undefined · MosaicReframe",
    "nameEn": "undefined · MosaicReframe",
    "category": "transition\\mosaic-reframe\\MosaicReframe",
    "categoryKey": "transition\\mosaic-reframe\\MosaicReframe"
  },
  "BarnDoorSplit": {
    "name": "undefined · BarnDoorSplit",
    "nameEn": "undefined · BarnDoorSplit",
    "category": "transition\\page-turn-transitions\\BarnDoorSplit",
    "categoryKey": "transition\\page-turn-transitions\\BarnDoorSplit"
  },
  "CubeRotate": {
    "name": "undefined · CubeRotate",
    "nameEn": "undefined · CubeRotate",
    "category": "transition\\page-turn-transitions\\CubeRotate",
    "categoryKey": "transition\\page-turn-transitions\\CubeRotate"
  },
  "PaperPlaneMessenger": {
    "name": "undefined · PaperPlaneMessenger",
    "nameEn": "undefined · PaperPlaneMessenger",
    "category": "transition\\paper-plane-messenger\\PaperPlaneMessenger",
    "categoryKey": "transition\\paper-plane-messenger\\PaperPlaneMessenger"
  },
  "InkBleedReveal": {
    "name": "undefined · InkBleedReveal",
    "nameEn": "undefined · InkBleedReveal",
    "category": "transition\\print-texture-transitions\\InkBleedReveal",
    "categoryKey": "transition\\print-texture-transitions\\InkBleedReveal"
  },
  "BlackCardTransition": {
    "name": "undefined · BlackCardTransition",
    "nameEn": "undefined · BlackCardTransition",
    "category": "transition\\shot-transitions\\BlackCardTransition",
    "categoryKey": "transition\\shot-transitions\\BlackCardTransition"
  },
  "DarkTunnelTransition": {
    "name": "undefined · DarkTunnelTransition",
    "nameEn": "undefined · DarkTunnelTransition",
    "category": "transition\\shot-transitions\\DarkTunnelTransition",
    "categoryKey": "transition\\shot-transitions\\DarkTunnelTransition"
  },
  "FocusHandoffTransition": {
    "name": "undefined · FocusHandoffTransition",
    "nameEn": "undefined · FocusHandoffTransition",
    "category": "transition\\shot-transitions\\FocusHandoffTransition",
    "categoryKey": "transition\\shot-transitions\\FocusHandoffTransition"
  },
  "MaskWipeReal": {
    "name": "undefined · MaskWipeReal",
    "nameEn": "undefined · MaskWipeReal",
    "category": "transition\\shot-transitions\\MaskWipeReal",
    "categoryKey": "transition\\shot-transitions\\MaskWipeReal"
  },
  "PortalWipeV2": {
    "name": "undefined · PortalWipeV2",
    "nameEn": "undefined · PortalWipeV2",
    "category": "transition\\shot-transitions\\PortalWipeV2",
    "categoryKey": "transition\\shot-transitions\\PortalWipeV2"
  },
  "WhipBrakeReal": {
    "name": "undefined · WhipBrakeReal",
    "nameEn": "undefined · WhipBrakeReal",
    "category": "transition\\shot-transitions\\WhipBrakeReal",
    "categoryKey": "transition\\shot-transitions\\WhipBrakeReal"
  },
  "WhipPanReal": {
    "name": "undefined · WhipPanReal",
    "nameEn": "undefined · WhipPanReal",
    "category": "transition\\shot-transitions\\WhipPanReal",
    "categoryKey": "transition\\shot-transitions\\WhipPanReal"
  },
  "GlitchDisplace": {
    "name": "undefined · GlitchDisplace",
    "nameEn": "undefined · GlitchDisplace",
    "category": "transition\\tear-streak-transitions\\GlitchDisplace",
    "categoryKey": "transition\\tear-streak-transitions\\GlitchDisplace"
  },
  "InvisibleCut": {
    "name": "undefined · InvisibleCut",
    "nameEn": "undefined · InvisibleCut",
    "category": "transition\\transition-hidden-cut\\InvisibleCut",
    "categoryKey": "transition\\transition-hidden-cut\\InvisibleCut"
  },
  "LightLeakBurn": {
    "name": "undefined · LightLeakBurn",
    "nameEn": "undefined · LightLeakBurn",
    "category": "transition\\transition-hidden-cut\\LightLeakBurn",
    "categoryKey": "transition\\transition-hidden-cut\\LightLeakBurn"
  },
  "VersusSlam": {
    "name": "undefined · VersusSlam",
    "nameEn": "undefined · VersusSlam",
    "category": "transition\\transition-hidden-cut\\VersusSlam",
    "categoryKey": "transition\\transition-hidden-cut\\VersusSlam"
  },
  "LetterformZoom": {
    "name": "undefined · LetterformZoom",
    "nameEn": "undefined · LetterformZoom",
    "category": "transition\\transition-travel\\LetterformZoom",
    "categoryKey": "transition\\transition-travel\\LetterformZoom"
  },
  "SharedElementMorph": {
    "name": "undefined · SharedElementMorph",
    "nameEn": "undefined · SharedElementMorph",
    "category": "transition\\transition-travel\\SharedElementMorph",
    "categoryKey": "transition\\transition-travel\\SharedElementMorph"
  },
  "WhiteFlashLogoSimplifyCut": {
    "name": "undefined · WhiteFlashLogoSimplifyCut",
    "nameEn": "undefined · WhiteFlashLogoSimplifyCut",
    "category": "transition\\white-flash-logo-simplify-cut\\WhiteFlashLogoSimplifyCut",
    "categoryKey": "transition\\white-flash-logo-simplify-cut\\WhiteFlashLogoSimplifyCut"
  },
  "BlindsSlice": {
    "name": "undefined · BlindsSlice",
    "nameEn": "undefined · BlindsSlice",
    "category": "transition\\wipe-transitions\\BlindsSlice",
    "categoryKey": "transition\\wipe-transitions\\BlindsSlice"
  },
  "ClockWipe": {
    "name": "undefined · ClockWipe",
    "nameEn": "undefined · ClockWipe",
    "category": "transition\\wipe-transitions\\ClockWipe",
    "categoryKey": "transition\\wipe-transitions\\ClockWipe"
  },
  "BlurSlide": {
    "name": "undefined · BlurSlide",
    "nameEn": "undefined · BlurSlide",
    "category": "typography\\blur-slide\\BlurSlide",
    "categoryKey": "typography\\blur-slide\\BlurSlide"
  },
  "BraceExpand": {
    "name": "undefined · BraceExpand",
    "nameEn": "undefined · BraceExpand",
    "category": "typography\\brace-expand\\BraceExpand",
    "categoryKey": "typography\\brace-expand\\BraceExpand"
  },
  "BrandInkOpen": {
    "name": "undefined · BrandInkOpen",
    "nameEn": "undefined · BrandInkOpen",
    "category": "typography\\brand-ink-open\\BrandInkOpen",
    "categoryKey": "typography\\brand-ink-open\\BrandInkOpen"
  },
  "CelFlashStomp": {
    "name": "undefined · CelFlashStomp",
    "nameEn": "undefined · CelFlashStomp",
    "category": "typography\\cel-flash-stomp\\CelFlashStomp",
    "categoryKey": "typography\\cel-flash-stomp\\CelFlashStomp"
  },
  "CountdownArcScatter": {
    "name": "undefined · CountdownArcScatter",
    "nameEn": "undefined · CountdownArcScatter",
    "category": "typography\\countdown-arc-scatter\\CountdownArcScatter",
    "categoryKey": "typography\\countdown-arc-scatter\\CountdownArcScatter"
  },
  "FlyingWords": {
    "name": "undefined · FlyingWords",
    "nameEn": "undefined · FlyingWords",
    "category": "typography\\flying-words\\FlyingWords",
    "categoryKey": "typography\\flying-words\\FlyingWords"
  },
  "GlitchCycle": {
    "name": "undefined · GlitchCycle",
    "nameEn": "undefined · GlitchCycle",
    "category": "typography\\glitch-cycle\\GlitchCycle",
    "categoryKey": "typography\\glitch-cycle\\GlitchCycle"
  },
  "GradientWordSweep": {
    "name": "undefined · GradientWordSweep",
    "nameEn": "undefined · GradientWordSweep",
    "category": "typography\\gradient-word-sweep\\GradientWordSweep",
    "categoryKey": "typography\\gradient-word-sweep\\GradientWordSweep"
  },
  "LeadWordZoomAssemble": {
    "name": "undefined · LeadWordZoomAssemble",
    "nameEn": "undefined · LeadWordZoomAssemble",
    "category": "typography\\lead-word-zoom-assemble\\LeadWordZoomAssemble",
    "categoryKey": "typography\\lead-word-zoom-assemble\\LeadWordZoomAssemble"
  },
  "MarkerUnderlineTitle": {
    "name": "undefined · MarkerUnderlineTitle",
    "nameEn": "undefined · MarkerUnderlineTitle",
    "category": "typography\\marker-underline-title\\MarkerUnderlineTitle",
    "categoryKey": "typography\\marker-underline-title\\MarkerUnderlineTitle"
  },
  "OutlineWordFill": {
    "name": "undefined · OutlineWordFill",
    "nameEn": "undefined · OutlineWordFill",
    "category": "typography\\outline-word-fill\\OutlineWordFill",
    "categoryKey": "typography\\outline-word-fill\\OutlineWordFill"
  },
  "PaperTitleCard": {
    "name": "undefined · PaperTitleCard",
    "nameEn": "undefined · PaperTitleCard",
    "category": "typography\\paper-title-card\\PaperTitleCard",
    "categoryKey": "typography\\paper-title-card\\PaperTitleCard"
  },
  "PillChipSlotCycleHandled": {
    "name": "undefined · PillChipSlotCycleHandled",
    "nameEn": "undefined · PillChipSlotCycleHandled",
    "category": "typography\\pill-chip-slot-cycle-handled\\PillChipSlotCycleHandled",
    "categoryKey": "typography\\pill-chip-slot-cycle-handled\\PillChipSlotCycleHandled"
  },
  "PillSlotCycle": {
    "name": "undefined · PillSlotCycle",
    "nameEn": "undefined · PillSlotCycle",
    "category": "typography\\pill-slot-cycle\\PillSlotCycle",
    "categoryKey": "typography\\pill-slot-cycle\\PillSlotCycle"
  },
  "Scramble": {
    "name": "undefined · Scramble",
    "nameEn": "undefined · Scramble",
    "category": "typography\\scramble\\Scramble",
    "categoryKey": "typography\\scramble\\Scramble"
  },
  "SplitFlapFlip": {
    "name": "undefined · SplitFlapFlip",
    "nameEn": "undefined · SplitFlapFlip",
    "category": "typography\\split-flap-title\\SplitFlapFlip",
    "categoryKey": "typography\\split-flap-title\\SplitFlapFlip"
  },
  "TextColumnConverge": {
    "name": "undefined · TextColumnConverge",
    "nameEn": "undefined · TextColumnConverge",
    "category": "typography\\text-column-converge\\TextColumnConverge",
    "categoryKey": "typography\\text-column-converge\\TextColumnConverge"
  },
  "TitleDemoteToLabel": {
    "name": "undefined · TitleDemoteToLabel",
    "nameEn": "undefined · TitleDemoteToLabel",
    "category": "typography\\title-demote-to-label\\TitleDemoteToLabel",
    "categoryKey": "typography\\title-demote-to-label\\TitleDemoteToLabel"
  },
  "LetterformDriftAssembly": {
    "name": "undefined · LetterformDriftAssembly",
    "nameEn": "undefined · LetterformDriftAssembly",
    "category": "typography\\type-assembly-moves\\LetterformDriftAssembly",
    "categoryKey": "typography\\type-assembly-moves\\LetterformDriftAssembly"
  },
  "SplitTextStagger": {
    "name": "undefined · SplitTextStagger",
    "nameEn": "undefined · SplitTextStagger",
    "category": "typography\\type-assembly-moves\\SplitTextStagger",
    "categoryKey": "typography\\type-assembly-moves\\SplitTextStagger"
  },
  "TextOnPath": {
    "name": "undefined · TextOnPath",
    "nameEn": "undefined · TextOnPath",
    "category": "typography\\type-assembly-moves\\TextOnPath",
    "categoryKey": "typography\\type-assembly-moves\\TextOnPath"
  },
  "TrackingExpandReveal": {
    "name": "undefined · TrackingExpandReveal",
    "nameEn": "undefined · TrackingExpandReveal",
    "category": "typography\\type-assembly-moves\\TrackingExpandReveal",
    "categoryKey": "typography\\type-assembly-moves\\TrackingExpandReveal"
  },
  "LetterDropPhysics": {
    "name": "undefined · LetterDropPhysics",
    "nameEn": "undefined · LetterDropPhysics",
    "category": "typography\\type-entrance-moves\\LetterDropPhysics",
    "categoryKey": "typography\\type-entrance-moves\\LetterDropPhysics"
  },
  "ScrambleDecode": {
    "name": "undefined · ScrambleDecode",
    "nameEn": "undefined · ScrambleDecode",
    "category": "typography\\type-entrance-moves\\ScrambleDecode",
    "categoryKey": "typography\\type-entrance-moves\\ScrambleDecode"
  },
  "FontWeightPump": {
    "name": "undefined · FontWeightPump",
    "nameEn": "undefined · FontWeightPump",
    "category": "typography\\type-rhythm-sync\\FontWeightPump",
    "categoryKey": "typography\\type-rhythm-sync\\FontWeightPump"
  },
  "KaraokeFillSync": {
    "name": "undefined · KaraokeFillSync",
    "nameEn": "undefined · KaraokeFillSync",
    "category": "typography\\type-rhythm-sync\\KaraokeFillSync",
    "categoryKey": "typography\\type-rhythm-sync\\KaraokeFillSync"
  },
  "TerminalTypewriter": {
    "name": "undefined · TerminalTypewriter",
    "nameEn": "undefined · TerminalTypewriter",
    "category": "typography\\typewriter-moves\\TerminalTypewriter",
    "categoryKey": "typography\\typewriter-moves\\TerminalTypewriter"
  },
  "TypewriterErrorRetype": {
    "name": "undefined · TypewriterErrorRetype",
    "nameEn": "undefined · TypewriterErrorRetype",
    "category": "typography\\typewriter-moves\\TypewriterErrorRetype",
    "categoryKey": "typography\\typewriter-moves\\TypewriterErrorRetype"
  },
  "TypingCodeBlock": {
    "name": "undefined · TypingCodeBlock",
    "nameEn": "undefined · TypingCodeBlock",
    "category": "typography\\typing-code-block\\TypingCodeBlock",
    "categoryKey": "typography\\typing-code-block\\TypingCodeBlock"
  },
  "VerticalWordRollBlurCycle": {
    "name": "undefined · VerticalWordRollBlurCycle",
    "nameEn": "undefined · VerticalWordRollBlurCycle",
    "category": "typography\\vertical-word-roll-blur-cycle\\VerticalWordRollBlurCycle",
    "categoryKey": "typography\\vertical-word-roll-blur-cycle\\VerticalWordRollBlurCycle"
  },
  "WordRelayFilmstrip": {
    "name": "undefined · WordRelayFilmstrip",
    "nameEn": "undefined · WordRelayFilmstrip",
    "category": "typography\\word-relay-filmstrip\\WordRelayFilmstrip",
    "categoryKey": "typography\\word-relay-filmstrip\\WordRelayFilmstrip"
  },
  "WordRelayGeometry": {
    "name": "undefined · WordRelayGeometry",
    "nameEn": "undefined · WordRelayGeometry",
    "category": "typography\\word-relay-geometry\\WordRelayGeometry",
    "categoryKey": "typography\\word-relay-geometry\\WordRelayGeometry"
  },
  "AvatarBracketCarousel": {
    "name": "undefined · AvatarBracketCarousel",
    "nameEn": "undefined · AvatarBracketCarousel",
    "category": "ui-entrance\\avatar-bracket-carousel\\AvatarBracketCarousel",
    "categoryKey": "ui-entrance\\avatar-bracket-carousel\\AvatarBracketCarousel"
  },
  "BezierSourceConvergeMerge": {
    "name": "undefined · BezierSourceConvergeMerge",
    "nameEn": "undefined · BezierSourceConvergeMerge",
    "category": "ui-entrance\\bezier-source-converge-merge\\BezierSourceConvergeMerge",
    "categoryKey": "ui-entrance\\bezier-source-converge-merge\\BezierSourceConvergeMerge"
  },
  "CardStack": {
    "name": "undefined · CardStack",
    "nameEn": "undefined · CardStack",
    "category": "ui-entrance\\card-stack\\CardStack",
    "categoryKey": "ui-entrance\\card-stack\\CardStack"
  },
  "Carousel3D": {
    "name": "undefined · Carousel3D",
    "nameEn": "undefined · Carousel3D",
    "category": "ui-entrance\\carousel-3d\\Carousel3D",
    "categoryKey": "ui-entrance\\carousel-3d\\Carousel3D"
  },
  "ClonerDepthEcho": {
    "name": "undefined · ClonerDepthEcho",
    "nameEn": "undefined · ClonerDepthEcho",
    "category": "ui-entrance\\cloner-depth-echo\\ClonerDepthEcho",
    "categoryKey": "ui-entrance\\cloner-depth-echo\\ClonerDepthEcho"
  },
  "DeckDealFlyin": {
    "name": "undefined · DeckDealFlyin",
    "nameEn": "undefined · DeckDealFlyin",
    "category": "ui-entrance\\deck-deal-flyin\\DeckDealFlyin",
    "categoryKey": "ui-entrance\\deck-deal-flyin\\DeckDealFlyin"
  },
  "DocParkLeftPillDeal": {
    "name": "undefined · DocParkLeftPillDeal",
    "nameEn": "undefined · DocParkLeftPillDeal",
    "category": "ui-entrance\\doc-park-left-pill-deal\\DocParkLeftPillDeal",
    "categoryKey": "ui-entrance\\doc-park-left-pill-deal\\DocParkLeftPillDeal"
  },
  "DocumentTypewriterReveal": {
    "name": "undefined · DocumentTypewriterReveal",
    "nameEn": "undefined · DocumentTypewriterReveal",
    "category": "ui-entrance\\document-typewriter-reveal\\DocumentTypewriterReveal",
    "categoryKey": "ui-entrance\\document-typewriter-reveal\\DocumentTypewriterReveal"
  },
  "DrawSvgTrace": {
    "name": "undefined · DrawSvgTrace",
    "nameEn": "undefined · DrawSvgTrace",
    "category": "ui-entrance\\draw-svg-trace\\DrawSvgTrace",
    "categoryKey": "ui-entrance\\draw-svg-trace\\DrawSvgTrace"
  },
  "AxialStretch": {
    "name": "undefined · AxialStretch",
    "nameEn": "undefined · AxialStretch",
    "category": "ui-entrance\\element-body-moves\\AxialStretch",
    "categoryKey": "ui-entrance\\element-body-moves\\AxialStretch"
  },
  "ContactShadowLift": {
    "name": "undefined · ContactShadowLift",
    "nameEn": "undefined · ContactShadowLift",
    "category": "ui-entrance\\element-body-moves\\ContactShadowLift",
    "categoryKey": "ui-entrance\\element-body-moves\\ContactShadowLift"
  },
  "FloatingGlossyLabelPills": {
    "name": "undefined · FloatingGlossyLabelPills",
    "nameEn": "undefined · FloatingGlossyLabelPills",
    "category": "ui-entrance\\floating-glossy-label-pills\\FloatingGlossyLabelPills",
    "categoryKey": "ui-entrance\\floating-glossy-label-pills\\FloatingGlossyLabelPills"
  },
  "IntegrationHubMap": {
    "name": "undefined · IntegrationHubMap",
    "nameEn": "undefined · IntegrationHubMap",
    "category": "ui-entrance\\integration-hub-map\\IntegrationHubMap",
    "categoryKey": "ui-entrance\\integration-hub-map\\IntegrationHubMap"
  },
  "ListReveal": {
    "name": "undefined · ListReveal",
    "nameEn": "undefined · ListReveal",
    "category": "ui-entrance\\list-reveal\\ListReveal",
    "categoryKey": "ui-entrance\\list-reveal\\ListReveal"
  },
  "ListStackPress": {
    "name": "undefined · ListStackPress",
    "nameEn": "undefined · ListStackPress",
    "category": "ui-entrance\\list-stack-press\\ListStackPress",
    "categoryKey": "ui-entrance\\list-stack-press\\ListStackPress"
  },
  "MorphFromPrimitive": {
    "name": "undefined · MorphFromPrimitive",
    "nameEn": "undefined · MorphFromPrimitive",
    "category": "ui-entrance\\morph-from-primitive\\MorphFromPrimitive",
    "categoryKey": "ui-entrance\\morph-from-primitive\\MorphFromPrimitive"
  },
  "NeonFrameForerun": {
    "name": "undefined · NeonFrameForerun",
    "nameEn": "undefined · NeonFrameForerun",
    "category": "ui-entrance\\neon-frame-forerun\\NeonFrameForerun",
    "categoryKey": "ui-entrance\\neon-frame-forerun\\NeonFrameForerun"
  },
  "NeonFrameForerunOrbit": {
    "name": "undefined · NeonFrameForerunOrbit",
    "nameEn": "undefined · NeonFrameForerunOrbit",
    "category": "ui-entrance\\neon-frame-orbit-drop\\NeonFrameForerunOrbit",
    "categoryKey": "ui-entrance\\neon-frame-orbit-drop\\NeonFrameForerunOrbit"
  },
  "PageWaterfallWall": {
    "name": "undefined · PageWaterfallWall",
    "nameEn": "undefined · PageWaterfallWall",
    "category": "ui-entrance\\page-waterfall-wall\\PageWaterfallWall",
    "categoryKey": "ui-entrance\\page-waterfall-wall\\PageWaterfallWall"
  },
  "MaskingTapeSlap": {
    "name": "undefined · MaskingTapeSlap",
    "nameEn": "undefined · MaskingTapeSlap",
    "category": "ui-entrance\\paper-craft-moves\\MaskingTapeSlap",
    "categoryKey": "ui-entrance\\paper-craft-moves\\MaskingTapeSlap"
  },
  "PopupBookRise": {
    "name": "undefined · PopupBookRise",
    "nameEn": "undefined · PopupBookRise",
    "category": "ui-entrance\\paper-craft-moves\\PopupBookRise",
    "categoryKey": "ui-entrance\\paper-craft-moves\\PopupBookRise"
  },
  "PlatformHingeRise": {
    "name": "undefined · PlatformHingeRise",
    "nameEn": "undefined · PlatformHingeRise",
    "category": "ui-entrance\\platform-hinge-rise\\PlatformHingeRise",
    "categoryKey": "ui-entrance\\platform-hinge-rise\\PlatformHingeRise"
  },
  "ProductCardProgressiveAssemble": {
    "name": "undefined · ProductCardProgressiveAssemble",
    "nameEn": "undefined · ProductCardProgressiveAssemble",
    "category": "ui-entrance\\product-card-progressive-assemble\\ProductCardProgressiveAssemble",
    "categoryKey": "ui-entrance\\product-card-progressive-assemble\\ProductCardProgressiveAssemble"
  },
  "RadialWave": {
    "name": "undefined · RadialWave",
    "nameEn": "undefined · RadialWave",
    "category": "ui-entrance\\radial-wave\\RadialWave",
    "categoryKey": "ui-entrance\\radial-wave\\RadialWave"
  },
  "ResearchCardStackScroll": {
    "name": "undefined · ResearchCardStackScroll",
    "nameEn": "undefined · ResearchCardStackScroll",
    "category": "ui-entrance\\research-card-stack-scroll\\ResearchCardStackScroll",
    "categoryKey": "ui-entrance\\research-card-stack-scroll\\ResearchCardStackScroll"
  },
  "RowEmbed": {
    "name": "undefined · RowEmbed",
    "nameEn": "undefined · RowEmbed",
    "category": "ui-entrance\\row-embed\\RowEmbed",
    "categoryKey": "ui-entrance\\row-embed\\RowEmbed"
  },
  "RunwayGroundSkim": {
    "name": "undefined · RunwayGroundSkim",
    "nameEn": "undefined · RunwayGroundSkim",
    "category": "ui-entrance\\runway-ground-skim\\RunwayGroundSkim",
    "categoryKey": "ui-entrance\\runway-ground-skim\\RunwayGroundSkim"
  },
  "SkeletonReveal": {
    "name": "undefined · SkeletonReveal",
    "nameEn": "undefined · SkeletonReveal",
    "category": "ui-entrance\\skeleton-reveal\\SkeletonReveal",
    "categoryKey": "ui-entrance\\skeleton-reveal\\SkeletonReveal"
  },
  "SvgShapeMorph": {
    "name": "undefined · SvgShapeMorph",
    "nameEn": "undefined · SvgShapeMorph",
    "category": "ui-entrance\\svg-shape-morph\\SvgShapeMorph",
    "categoryKey": "ui-entrance\\svg-shape-morph\\SvgShapeMorph"
  },
  "ValueStaggerGradient": {
    "name": "undefined · ValueStaggerGradient",
    "nameEn": "undefined · ValueStaggerGradient",
    "category": "ui-entrance\\value-stagger-gradient\\ValueStaggerGradient",
    "categoryKey": "ui-entrance\\value-stagger-gradient\\ValueStaggerGradient"
  },
  "BentoLightUp": {
    "name": "undefined · BentoLightUp",
    "nameEn": "undefined · BentoLightUp",
    "category": "ui-entrance\\wall-reveal-moves\\BentoLightUp",
    "categoryKey": "ui-entrance\\wall-reveal-moves\\BentoLightUp"
  },
  "GridWaveFlip": {
    "name": "undefined · GridWaveFlip",
    "nameEn": "undefined · GridWaveFlip",
    "category": "ui-entrance\\wall-reveal-moves\\GridWaveFlip",
    "categoryKey": "ui-entrance\\wall-reveal-moves\\GridWaveFlip"
  },
  "WireframeDrawOn": {
    "name": "undefined · WireframeDrawOn",
    "nameEn": "undefined · WireframeDrawOn",
    "category": "ui-entrance\\wall-reveal-moves\\WireframeDrawOn",
    "categoryKey": "ui-entrance\\wall-reveal-moves\\WireframeDrawOn"
  }
};

/** 画廊分类（中文，按画廊顺序），只含有 demo 的分类 */
export const DEMO_CATEGORIES: string[] = ["camera\\basic-3d-scene\\Basic3DScene","camera\\crash-zoom-punch\\CrashImpactReal","camera\\crash-zoom-punch\\CrashZoomReal","camera\\cursor-flyover\\CursorFlyover","camera\\depth-layer-moves\\DollyZoomReal","camera\\depth-layer-moves\\MultiplaneReal","camera\\graze-face-tour\\GrazeFaceTour","camera\\overhead-camera-moves\\OverheadTabletopDrop","camera\\overhead-camera-moves\\TiltReveal","camera\\space-camera-moves\\DroneDiveLanding","camera\\space-camera-moves\\ExplodedView","camera\\steep-tilt-glide\\SteepTiltGlide","camera\\tension-camera-moves\\BulletTimeFreezeOrbit","camera\\tension-camera-moves\\DutchRollToLevel","camera\\tension-camera-moves\\PullBackIsolation","camera\\tension-camera-moves\\SlowPushIn","camera\\terminal-3d\\Terminal3D","data\\avatar-grid-radial-build-colorize\\AvatarGridRadialBuildColorize","data\\before-after-slider-scrub\\BeforeAfterSliderScrub","data\\chart-live-moves\\AxisRescaleShockV2","data\\chart-live-moves\\OscilloscopeStreamV2","data\\chart-live-moves\\UnitDotSwarmRegroupV2","data\\counter-confetti\\CounterConfetti","data\\cycle-glass-node-morph\\CycleGlassNodeMorph","data\\gauge-readout-moves\\NeedleSweepSelftest","data\\gauge-readout-moves\\TapeScrollFixedPointer","data\\hatch-depth\\HatchDepth","data\\odometer-digit-roll\\OdometerDigitRoll","data\\particle-celebrate-hits\\ConfettiCrossfire","data\\particle-celebrate-hits\\CounterTickSparks","data\\particle-sand-fill\\ParticleSandFill","data\\ring-diagram-annotation-reveal\\RingDiagramAnnotationReveal","data\\scroll-brake-moves\\BrakeReticleLock","data\\scroll-brake-moves\\ChangelogScrollBrake","data\\timeline-travel\\TimelineTravel","effects\\assemble-then-type-flyin\\AssembleThenTypeFlyin","effects\\aurora-bloom-bg-flip\\AuroraBloomBgFlip","effects\\brand-frame-snap\\BrandFrameSnap","effects\\dashboard-glow-highlight-pill\\DashboardGlowHighlightPill","effects\\fui-hud-moves\\LineUnfoldPanel","effects\\fui-hud-moves\\ReticleLockOn","effects\\glow-flyline-moves\\FlylineArc","effects\\glow-flyline-moves\\GlowOrbAmbient","effects\\glow-flyline-moves\\OrbFlylineRelay","effects\\icon-performance-moves\\AttentionBounce","effects\\icon-performance-moves\\PopBurstConfirm","effects\\impact-feedback\\AnimeImpact","effects\\impact-feedback\\HitCounter","effects\\light-play-moves\\HalationBloom","effects\\light-play-moves\\SheenSweepRetry","effects\\light-play-moves\\SpotlightSweepReveal","effects\\line-boil\\LineBoil","effects\\radial-ripple-phone-chips\\RadialRipplePhoneChips","effects\\riso-print-hits\\RisoBeatPump","effects\\riso-print-hits\\RisoMisregistrationHit","effects\\scan-bracket-sweep\\ScanBracketSweep","effects\\scanline-annotate-focus\\ScanlineAnnotateFocus","effects\\scanline-assemble-flyin\\ScanlineAssembleFlyin","effects\\slam-entrance-moves\\ImpactBurstKit","effects\\slam-entrance-moves\\KanadaPerspectiveSnap","effects\\slam-entrance-moves\\ScoreSlam","effects\\spotlight-sweep-moves\\CornerSpotlightReveal","effects\\spotlight-sweep-moves\\GlowWakeSleepPanel","effects\\spotlight-sweep-moves\\SlideSpotlightPan","interaction\\ai-stream-response\\StreamResponse","interaction\\autolayout-gap-dial\\AutolayoutGapDial","interaction\\canvas-materialize-moves\\DiagramCascadeBuild","interaction\\canvas-materialize-moves\\PanelToCanvasMaterialize","interaction\\chip-grid-single-select-blackout\\ChipGridSingleSelectBlackout","interaction\\chip-lift-to-user-pill\\ChipLiftToUserPill","interaction\\collab-cursor-moves\\CursorCastEnsemble","interaction\\collab-cursor-moves\\CursorDialogueDuet","interaction\\command-palette-summon\\CommandPaletteSummon","interaction\\glass-pill-dictation-typing\\GlassPillDictationTyping","interaction\\hashtag-to-pill-materialize\\HashtagToPillMaterialize","interaction\\input-trigger-moves\\CursorPerformancePunchIn","interaction\\input-trigger-moves\\KeycapSmashCut","interaction\\picker-carousel-feature-cycle\\PickerCarouselFeatureCycle","interaction\\segmented-thumb-hero\\SegmentedThumbHero","interaction\\theme-switch-moves\\PaletteThemeRipple","interaction\\theme-switch-moves\\ThemeSweepToggle","interaction\\type-and-filter\\TypeAndFilter","interaction\\voice-waveform-live\\VoiceWaveformLive","opening\\crane-rise-reveal\\CraneRiseReveal","opening\\dataviz-landscape-open\\DatavizLandscapeOpen","opening\\fracture\\Fracture","opening\\icon-field-colorize\\IconFieldColorize","opening\\letterspace-materialize\\LetterspaceMaterialize","opening\\magician-card-flourish\\MagicianCardFlourish","opening\\orbit-ring-title-open\\OrbitRingTitleOpen","opening\\spotlight-hero-card\\SpotlightHeroCard","opening\\stroke-segment-build\\StrokeSegmentBuild","opening\\text-as-mask\\TextAsMask","outro\\edit-hook-moves\\LogoStingButton","outro\\grain-dissolve\\GrainDissolve","outro\\logo-shrink-wordmark-lockup\\LogoShrinkWordmarkLockup","outro\\neon-triple-marquee\\NeonTripleMarquee","outro\\outro-group-photo-launch\\OutroGroupPhotoLaunch","outro\\ui-strip-away-outro\\UiStripAwayOutro","outro\\ui-to-brand-morph\\IconFlipBloomLogo","outro\\ui-to-brand-morph\\InputMorphsIntoLogo","rhythm\\beat-cut-moves\\BeatCutAccelerando","rhythm\\beat-cut-moves\\PaparazziFlash","rhythm\\beat-step-list-theme-cycle\\BeatStepListThemeCycle","rhythm\\montage-rhythm-moves\\DominoCascade","rhythm\\montage-rhythm-moves\\DropBlackoutSlam","rhythm\\montage-rhythm-moves\\WrightTripleCut","rhythm\\panel-grid-moves\\ComicPanelSplit","rhythm\\panel-grid-moves\\FlipGridReflow","rhythm\\panel-grid-moves\\GridFlashMosaic","rhythm\\quad-split-parallel-scenes\\QuadSplitParallelScenes","rhythm\\rhythm-interrupt-moves\\JumpCutPunchIn","rhythm\\rhythm-interrupt-moves\\StrobeBlackFrames","rhythm\\sakuga-timing-shift\\SakugaTimingShift","rhythm\\smear-multiples\\SmearMultiples","rhythm\\spectrum-morph-ui\\SpectrumMorphUi","rhythm\\speed-ramp-freeze\\FreezeAnnotateReal","rhythm\\speed-ramp-freeze\\SpeedRampReal","rhythm\\trailer-grammar-moves\\CardFootageCadence","rhythm\\trailer-grammar-moves\\SmashCut","rhythm\\trailer-grammar-moves\\TrailerBumper","transition\\bottom-push-stack-wipe\\BottomPushStackWipe","transition\\bubble-swarm-takeover\\BubbleSwarmTakeover","transition\\card-flip-reveal\\CardFlipReveal","transition\\card-flock-tumble\\CardFlockTumble","transition\\circle-match-iris\\CircleMatchIris","transition\\color-block-step-wipe\\ColorBlockStepWipe","transition\\cube-navigation\\CubeNavigation","transition\\gradient-transition\\GradientTransition","transition\\line-carry-transition\\LineCarryTransition","transition\\mosaic-reframe\\MosaicReframe","transition\\page-turn-transitions\\BarnDoorSplit","transition\\page-turn-transitions\\CubeRotate","transition\\paper-plane-messenger\\PaperPlaneMessenger","transition\\print-texture-transitions\\InkBleedReveal","transition\\shot-transitions\\BlackCardTransition","transition\\shot-transitions\\DarkTunnelTransition","transition\\shot-transitions\\FocusHandoffTransition","transition\\shot-transitions\\MaskWipeReal","transition\\shot-transitions\\PortalWipeV2","transition\\shot-transitions\\WhipBrakeReal","transition\\shot-transitions\\WhipPanReal","transition\\tear-streak-transitions\\GlitchDisplace","transition\\transition-hidden-cut\\InvisibleCut","transition\\transition-hidden-cut\\LightLeakBurn","transition\\transition-hidden-cut\\VersusSlam","transition\\transition-travel\\LetterformZoom","transition\\transition-travel\\SharedElementMorph","transition\\white-flash-logo-simplify-cut\\WhiteFlashLogoSimplifyCut","transition\\wipe-transitions\\BlindsSlice","transition\\wipe-transitions\\ClockWipe","typography\\blur-slide\\BlurSlide","typography\\brace-expand\\BraceExpand","typography\\brand-ink-open\\BrandInkOpen","typography\\cel-flash-stomp\\CelFlashStomp","typography\\countdown-arc-scatter\\CountdownArcScatter","typography\\flying-words\\FlyingWords","typography\\glitch-cycle\\GlitchCycle","typography\\gradient-word-sweep\\GradientWordSweep","typography\\lead-word-zoom-assemble\\LeadWordZoomAssemble","typography\\marker-underline-title\\MarkerUnderlineTitle","typography\\outline-word-fill\\OutlineWordFill","typography\\paper-title-card\\PaperTitleCard","typography\\pill-chip-slot-cycle-handled\\PillChipSlotCycleHandled","typography\\pill-slot-cycle\\PillSlotCycle","typography\\scramble\\Scramble","typography\\split-flap-title\\SplitFlapFlip","typography\\text-column-converge\\TextColumnConverge","typography\\title-demote-to-label\\TitleDemoteToLabel","typography\\type-assembly-moves\\LetterformDriftAssembly","typography\\type-assembly-moves\\SplitTextStagger","typography\\type-assembly-moves\\TextOnPath","typography\\type-assembly-moves\\TrackingExpandReveal","typography\\type-entrance-moves\\LetterDropPhysics","typography\\type-entrance-moves\\ScrambleDecode","typography\\type-rhythm-sync\\FontWeightPump","typography\\type-rhythm-sync\\KaraokeFillSync","typography\\typewriter-moves\\TerminalTypewriter","typography\\typewriter-moves\\TypewriterErrorRetype","typography\\typing-code-block\\TypingCodeBlock","typography\\vertical-word-roll-blur-cycle\\VerticalWordRollBlurCycle","typography\\word-relay-filmstrip\\WordRelayFilmstrip","typography\\word-relay-geometry\\WordRelayGeometry","ui-entrance\\avatar-bracket-carousel\\AvatarBracketCarousel","ui-entrance\\bezier-source-converge-merge\\BezierSourceConvergeMerge","ui-entrance\\card-stack\\CardStack","ui-entrance\\carousel-3d\\Carousel3D","ui-entrance\\cloner-depth-echo\\ClonerDepthEcho","ui-entrance\\deck-deal-flyin\\DeckDealFlyin","ui-entrance\\doc-park-left-pill-deal\\DocParkLeftPillDeal","ui-entrance\\document-typewriter-reveal\\DocumentTypewriterReveal","ui-entrance\\draw-svg-trace\\DrawSvgTrace","ui-entrance\\element-body-moves\\AxialStretch","ui-entrance\\element-body-moves\\ContactShadowLift","ui-entrance\\floating-glossy-label-pills\\FloatingGlossyLabelPills","ui-entrance\\integration-hub-map\\IntegrationHubMap","ui-entrance\\list-reveal\\ListReveal","ui-entrance\\list-stack-press\\ListStackPress","ui-entrance\\morph-from-primitive\\MorphFromPrimitive","ui-entrance\\neon-frame-forerun\\NeonFrameForerun","ui-entrance\\neon-frame-orbit-drop\\NeonFrameForerunOrbit","ui-entrance\\page-waterfall-wall\\PageWaterfallWall","ui-entrance\\paper-craft-moves\\MaskingTapeSlap","ui-entrance\\paper-craft-moves\\PopupBookRise","ui-entrance\\platform-hinge-rise\\PlatformHingeRise","ui-entrance\\product-card-progressive-assemble\\ProductCardProgressiveAssemble","ui-entrance\\radial-wave\\RadialWave","ui-entrance\\research-card-stack-scroll\\ResearchCardStackScroll","ui-entrance\\row-embed\\RowEmbed","ui-entrance\\runway-ground-skim\\RunwayGroundSkim","ui-entrance\\skeleton-reveal\\SkeletonReveal","ui-entrance\\svg-shape-morph\\SvgShapeMorph","ui-entrance\\value-stagger-gradient\\ValueStaggerGradient","ui-entrance\\wall-reveal-moves\\BentoLightUp","ui-entrance\\wall-reveal-moves\\GridWaveFlip","ui-entrance\\wall-reveal-moves\\WireframeDrawOn"];
/** 分类中文名 → 英文名（i18n 词典合并用，英文界面按此显示分类） */
export const DEMO_CATEGORY_EN: Record<string, string> = {"camera\\basic-3d-scene\\Basic3DScene":"camera\\basic-3d-scene\\Basic3DScene","camera\\crash-zoom-punch\\CrashImpactReal":"camera\\crash-zoom-punch\\CrashImpactReal","camera\\crash-zoom-punch\\CrashZoomReal":"camera\\crash-zoom-punch\\CrashZoomReal","camera\\cursor-flyover\\CursorFlyover":"camera\\cursor-flyover\\CursorFlyover","camera\\depth-layer-moves\\DollyZoomReal":"camera\\depth-layer-moves\\DollyZoomReal","camera\\depth-layer-moves\\MultiplaneReal":"camera\\depth-layer-moves\\MultiplaneReal","camera\\graze-face-tour\\GrazeFaceTour":"camera\\graze-face-tour\\GrazeFaceTour","camera\\overhead-camera-moves\\OverheadTabletopDrop":"camera\\overhead-camera-moves\\OverheadTabletopDrop","camera\\overhead-camera-moves\\TiltReveal":"camera\\overhead-camera-moves\\TiltReveal","camera\\space-camera-moves\\DroneDiveLanding":"camera\\space-camera-moves\\DroneDiveLanding","camera\\space-camera-moves\\ExplodedView":"camera\\space-camera-moves\\ExplodedView","camera\\steep-tilt-glide\\SteepTiltGlide":"camera\\steep-tilt-glide\\SteepTiltGlide","camera\\tension-camera-moves\\BulletTimeFreezeOrbit":"camera\\tension-camera-moves\\BulletTimeFreezeOrbit","camera\\tension-camera-moves\\DutchRollToLevel":"camera\\tension-camera-moves\\DutchRollToLevel","camera\\tension-camera-moves\\PullBackIsolation":"camera\\tension-camera-moves\\PullBackIsolation","camera\\tension-camera-moves\\SlowPushIn":"camera\\tension-camera-moves\\SlowPushIn","camera\\terminal-3d\\Terminal3D":"camera\\terminal-3d\\Terminal3D","data\\avatar-grid-radial-build-colorize\\AvatarGridRadialBuildColorize":"data\\avatar-grid-radial-build-colorize\\AvatarGridRadialBuildColorize","data\\before-after-slider-scrub\\BeforeAfterSliderScrub":"data\\before-after-slider-scrub\\BeforeAfterSliderScrub","data\\chart-live-moves\\AxisRescaleShockV2":"data\\chart-live-moves\\AxisRescaleShockV2","data\\chart-live-moves\\OscilloscopeStreamV2":"data\\chart-live-moves\\OscilloscopeStreamV2","data\\chart-live-moves\\UnitDotSwarmRegroupV2":"data\\chart-live-moves\\UnitDotSwarmRegroupV2","data\\counter-confetti\\CounterConfetti":"data\\counter-confetti\\CounterConfetti","data\\cycle-glass-node-morph\\CycleGlassNodeMorph":"data\\cycle-glass-node-morph\\CycleGlassNodeMorph","data\\gauge-readout-moves\\NeedleSweepSelftest":"data\\gauge-readout-moves\\NeedleSweepSelftest","data\\gauge-readout-moves\\TapeScrollFixedPointer":"data\\gauge-readout-moves\\TapeScrollFixedPointer","data\\hatch-depth\\HatchDepth":"data\\hatch-depth\\HatchDepth","data\\odometer-digit-roll\\OdometerDigitRoll":"data\\odometer-digit-roll\\OdometerDigitRoll","data\\particle-celebrate-hits\\ConfettiCrossfire":"data\\particle-celebrate-hits\\ConfettiCrossfire","data\\particle-celebrate-hits\\CounterTickSparks":"data\\particle-celebrate-hits\\CounterTickSparks","data\\particle-sand-fill\\ParticleSandFill":"data\\particle-sand-fill\\ParticleSandFill","data\\ring-diagram-annotation-reveal\\RingDiagramAnnotationReveal":"data\\ring-diagram-annotation-reveal\\RingDiagramAnnotationReveal","data\\scroll-brake-moves\\BrakeReticleLock":"data\\scroll-brake-moves\\BrakeReticleLock","data\\scroll-brake-moves\\ChangelogScrollBrake":"data\\scroll-brake-moves\\ChangelogScrollBrake","data\\timeline-travel\\TimelineTravel":"data\\timeline-travel\\TimelineTravel","effects\\assemble-then-type-flyin\\AssembleThenTypeFlyin":"effects\\assemble-then-type-flyin\\AssembleThenTypeFlyin","effects\\aurora-bloom-bg-flip\\AuroraBloomBgFlip":"effects\\aurora-bloom-bg-flip\\AuroraBloomBgFlip","effects\\brand-frame-snap\\BrandFrameSnap":"effects\\brand-frame-snap\\BrandFrameSnap","effects\\dashboard-glow-highlight-pill\\DashboardGlowHighlightPill":"effects\\dashboard-glow-highlight-pill\\DashboardGlowHighlightPill","effects\\fui-hud-moves\\LineUnfoldPanel":"effects\\fui-hud-moves\\LineUnfoldPanel","effects\\fui-hud-moves\\ReticleLockOn":"effects\\fui-hud-moves\\ReticleLockOn","effects\\glow-flyline-moves\\FlylineArc":"effects\\glow-flyline-moves\\FlylineArc","effects\\glow-flyline-moves\\GlowOrbAmbient":"effects\\glow-flyline-moves\\GlowOrbAmbient","effects\\glow-flyline-moves\\OrbFlylineRelay":"effects\\glow-flyline-moves\\OrbFlylineRelay","effects\\icon-performance-moves\\AttentionBounce":"effects\\icon-performance-moves\\AttentionBounce","effects\\icon-performance-moves\\PopBurstConfirm":"effects\\icon-performance-moves\\PopBurstConfirm","effects\\impact-feedback\\AnimeImpact":"effects\\impact-feedback\\AnimeImpact","effects\\impact-feedback\\HitCounter":"effects\\impact-feedback\\HitCounter","effects\\light-play-moves\\HalationBloom":"effects\\light-play-moves\\HalationBloom","effects\\light-play-moves\\SheenSweepRetry":"effects\\light-play-moves\\SheenSweepRetry","effects\\light-play-moves\\SpotlightSweepReveal":"effects\\light-play-moves\\SpotlightSweepReveal","effects\\line-boil\\LineBoil":"effects\\line-boil\\LineBoil","effects\\radial-ripple-phone-chips\\RadialRipplePhoneChips":"effects\\radial-ripple-phone-chips\\RadialRipplePhoneChips","effects\\riso-print-hits\\RisoBeatPump":"effects\\riso-print-hits\\RisoBeatPump","effects\\riso-print-hits\\RisoMisregistrationHit":"effects\\riso-print-hits\\RisoMisregistrationHit","effects\\scan-bracket-sweep\\ScanBracketSweep":"effects\\scan-bracket-sweep\\ScanBracketSweep","effects\\scanline-annotate-focus\\ScanlineAnnotateFocus":"effects\\scanline-annotate-focus\\ScanlineAnnotateFocus","effects\\scanline-assemble-flyin\\ScanlineAssembleFlyin":"effects\\scanline-assemble-flyin\\ScanlineAssembleFlyin","effects\\slam-entrance-moves\\ImpactBurstKit":"effects\\slam-entrance-moves\\ImpactBurstKit","effects\\slam-entrance-moves\\KanadaPerspectiveSnap":"effects\\slam-entrance-moves\\KanadaPerspectiveSnap","effects\\slam-entrance-moves\\ScoreSlam":"effects\\slam-entrance-moves\\ScoreSlam","effects\\spotlight-sweep-moves\\CornerSpotlightReveal":"effects\\spotlight-sweep-moves\\CornerSpotlightReveal","effects\\spotlight-sweep-moves\\GlowWakeSleepPanel":"effects\\spotlight-sweep-moves\\GlowWakeSleepPanel","effects\\spotlight-sweep-moves\\SlideSpotlightPan":"effects\\spotlight-sweep-moves\\SlideSpotlightPan","interaction\\ai-stream-response\\StreamResponse":"interaction\\ai-stream-response\\StreamResponse","interaction\\autolayout-gap-dial\\AutolayoutGapDial":"interaction\\autolayout-gap-dial\\AutolayoutGapDial","interaction\\canvas-materialize-moves\\DiagramCascadeBuild":"interaction\\canvas-materialize-moves\\DiagramCascadeBuild","interaction\\canvas-materialize-moves\\PanelToCanvasMaterialize":"interaction\\canvas-materialize-moves\\PanelToCanvasMaterialize","interaction\\chip-grid-single-select-blackout\\ChipGridSingleSelectBlackout":"interaction\\chip-grid-single-select-blackout\\ChipGridSingleSelectBlackout","interaction\\chip-lift-to-user-pill\\ChipLiftToUserPill":"interaction\\chip-lift-to-user-pill\\ChipLiftToUserPill","interaction\\collab-cursor-moves\\CursorCastEnsemble":"interaction\\collab-cursor-moves\\CursorCastEnsemble","interaction\\collab-cursor-moves\\CursorDialogueDuet":"interaction\\collab-cursor-moves\\CursorDialogueDuet","interaction\\command-palette-summon\\CommandPaletteSummon":"interaction\\command-palette-summon\\CommandPaletteSummon","interaction\\glass-pill-dictation-typing\\GlassPillDictationTyping":"interaction\\glass-pill-dictation-typing\\GlassPillDictationTyping","interaction\\hashtag-to-pill-materialize\\HashtagToPillMaterialize":"interaction\\hashtag-to-pill-materialize\\HashtagToPillMaterialize","interaction\\input-trigger-moves\\CursorPerformancePunchIn":"interaction\\input-trigger-moves\\CursorPerformancePunchIn","interaction\\input-trigger-moves\\KeycapSmashCut":"interaction\\input-trigger-moves\\KeycapSmashCut","interaction\\picker-carousel-feature-cycle\\PickerCarouselFeatureCycle":"interaction\\picker-carousel-feature-cycle\\PickerCarouselFeatureCycle","interaction\\segmented-thumb-hero\\SegmentedThumbHero":"interaction\\segmented-thumb-hero\\SegmentedThumbHero","interaction\\theme-switch-moves\\PaletteThemeRipple":"interaction\\theme-switch-moves\\PaletteThemeRipple","interaction\\theme-switch-moves\\ThemeSweepToggle":"interaction\\theme-switch-moves\\ThemeSweepToggle","interaction\\type-and-filter\\TypeAndFilter":"interaction\\type-and-filter\\TypeAndFilter","interaction\\voice-waveform-live\\VoiceWaveformLive":"interaction\\voice-waveform-live\\VoiceWaveformLive","opening\\crane-rise-reveal\\CraneRiseReveal":"opening\\crane-rise-reveal\\CraneRiseReveal","opening\\dataviz-landscape-open\\DatavizLandscapeOpen":"opening\\dataviz-landscape-open\\DatavizLandscapeOpen","opening\\fracture\\Fracture":"opening\\fracture\\Fracture","opening\\icon-field-colorize\\IconFieldColorize":"opening\\icon-field-colorize\\IconFieldColorize","opening\\letterspace-materialize\\LetterspaceMaterialize":"opening\\letterspace-materialize\\LetterspaceMaterialize","opening\\magician-card-flourish\\MagicianCardFlourish":"opening\\magician-card-flourish\\MagicianCardFlourish","opening\\orbit-ring-title-open\\OrbitRingTitleOpen":"opening\\orbit-ring-title-open\\OrbitRingTitleOpen","opening\\spotlight-hero-card\\SpotlightHeroCard":"opening\\spotlight-hero-card\\SpotlightHeroCard","opening\\stroke-segment-build\\StrokeSegmentBuild":"opening\\stroke-segment-build\\StrokeSegmentBuild","opening\\text-as-mask\\TextAsMask":"opening\\text-as-mask\\TextAsMask","outro\\edit-hook-moves\\LogoStingButton":"outro\\edit-hook-moves\\LogoStingButton","outro\\grain-dissolve\\GrainDissolve":"outro\\grain-dissolve\\GrainDissolve","outro\\logo-shrink-wordmark-lockup\\LogoShrinkWordmarkLockup":"outro\\logo-shrink-wordmark-lockup\\LogoShrinkWordmarkLockup","outro\\neon-triple-marquee\\NeonTripleMarquee":"outro\\neon-triple-marquee\\NeonTripleMarquee","outro\\outro-group-photo-launch\\OutroGroupPhotoLaunch":"outro\\outro-group-photo-launch\\OutroGroupPhotoLaunch","outro\\ui-strip-away-outro\\UiStripAwayOutro":"outro\\ui-strip-away-outro\\UiStripAwayOutro","outro\\ui-to-brand-morph\\IconFlipBloomLogo":"outro\\ui-to-brand-morph\\IconFlipBloomLogo","outro\\ui-to-brand-morph\\InputMorphsIntoLogo":"outro\\ui-to-brand-morph\\InputMorphsIntoLogo","rhythm\\beat-cut-moves\\BeatCutAccelerando":"rhythm\\beat-cut-moves\\BeatCutAccelerando","rhythm\\beat-cut-moves\\PaparazziFlash":"rhythm\\beat-cut-moves\\PaparazziFlash","rhythm\\beat-step-list-theme-cycle\\BeatStepListThemeCycle":"rhythm\\beat-step-list-theme-cycle\\BeatStepListThemeCycle","rhythm\\montage-rhythm-moves\\DominoCascade":"rhythm\\montage-rhythm-moves\\DominoCascade","rhythm\\montage-rhythm-moves\\DropBlackoutSlam":"rhythm\\montage-rhythm-moves\\DropBlackoutSlam","rhythm\\montage-rhythm-moves\\WrightTripleCut":"rhythm\\montage-rhythm-moves\\WrightTripleCut","rhythm\\panel-grid-moves\\ComicPanelSplit":"rhythm\\panel-grid-moves\\ComicPanelSplit","rhythm\\panel-grid-moves\\FlipGridReflow":"rhythm\\panel-grid-moves\\FlipGridReflow","rhythm\\panel-grid-moves\\GridFlashMosaic":"rhythm\\panel-grid-moves\\GridFlashMosaic","rhythm\\quad-split-parallel-scenes\\QuadSplitParallelScenes":"rhythm\\quad-split-parallel-scenes\\QuadSplitParallelScenes","rhythm\\rhythm-interrupt-moves\\JumpCutPunchIn":"rhythm\\rhythm-interrupt-moves\\JumpCutPunchIn","rhythm\\rhythm-interrupt-moves\\StrobeBlackFrames":"rhythm\\rhythm-interrupt-moves\\StrobeBlackFrames","rhythm\\sakuga-timing-shift\\SakugaTimingShift":"rhythm\\sakuga-timing-shift\\SakugaTimingShift","rhythm\\smear-multiples\\SmearMultiples":"rhythm\\smear-multiples\\SmearMultiples","rhythm\\spectrum-morph-ui\\SpectrumMorphUi":"rhythm\\spectrum-morph-ui\\SpectrumMorphUi","rhythm\\speed-ramp-freeze\\FreezeAnnotateReal":"rhythm\\speed-ramp-freeze\\FreezeAnnotateReal","rhythm\\speed-ramp-freeze\\SpeedRampReal":"rhythm\\speed-ramp-freeze\\SpeedRampReal","rhythm\\trailer-grammar-moves\\CardFootageCadence":"rhythm\\trailer-grammar-moves\\CardFootageCadence","rhythm\\trailer-grammar-moves\\SmashCut":"rhythm\\trailer-grammar-moves\\SmashCut","rhythm\\trailer-grammar-moves\\TrailerBumper":"rhythm\\trailer-grammar-moves\\TrailerBumper","transition\\bottom-push-stack-wipe\\BottomPushStackWipe":"transition\\bottom-push-stack-wipe\\BottomPushStackWipe","transition\\bubble-swarm-takeover\\BubbleSwarmTakeover":"transition\\bubble-swarm-takeover\\BubbleSwarmTakeover","transition\\card-flip-reveal\\CardFlipReveal":"transition\\card-flip-reveal\\CardFlipReveal","transition\\card-flock-tumble\\CardFlockTumble":"transition\\card-flock-tumble\\CardFlockTumble","transition\\circle-match-iris\\CircleMatchIris":"transition\\circle-match-iris\\CircleMatchIris","transition\\color-block-step-wipe\\ColorBlockStepWipe":"transition\\color-block-step-wipe\\ColorBlockStepWipe","transition\\cube-navigation\\CubeNavigation":"transition\\cube-navigation\\CubeNavigation","transition\\gradient-transition\\GradientTransition":"transition\\gradient-transition\\GradientTransition","transition\\line-carry-transition\\LineCarryTransition":"transition\\line-carry-transition\\LineCarryTransition","transition\\mosaic-reframe\\MosaicReframe":"transition\\mosaic-reframe\\MosaicReframe","transition\\page-turn-transitions\\BarnDoorSplit":"transition\\page-turn-transitions\\BarnDoorSplit","transition\\page-turn-transitions\\CubeRotate":"transition\\page-turn-transitions\\CubeRotate","transition\\paper-plane-messenger\\PaperPlaneMessenger":"transition\\paper-plane-messenger\\PaperPlaneMessenger","transition\\print-texture-transitions\\InkBleedReveal":"transition\\print-texture-transitions\\InkBleedReveal","transition\\shot-transitions\\BlackCardTransition":"transition\\shot-transitions\\BlackCardTransition","transition\\shot-transitions\\DarkTunnelTransition":"transition\\shot-transitions\\DarkTunnelTransition","transition\\shot-transitions\\FocusHandoffTransition":"transition\\shot-transitions\\FocusHandoffTransition","transition\\shot-transitions\\MaskWipeReal":"transition\\shot-transitions\\MaskWipeReal","transition\\shot-transitions\\PortalWipeV2":"transition\\shot-transitions\\PortalWipeV2","transition\\shot-transitions\\WhipBrakeReal":"transition\\shot-transitions\\WhipBrakeReal","transition\\shot-transitions\\WhipPanReal":"transition\\shot-transitions\\WhipPanReal","transition\\tear-streak-transitions\\GlitchDisplace":"transition\\tear-streak-transitions\\GlitchDisplace","transition\\transition-hidden-cut\\InvisibleCut":"transition\\transition-hidden-cut\\InvisibleCut","transition\\transition-hidden-cut\\LightLeakBurn":"transition\\transition-hidden-cut\\LightLeakBurn","transition\\transition-hidden-cut\\VersusSlam":"transition\\transition-hidden-cut\\VersusSlam","transition\\transition-travel\\LetterformZoom":"transition\\transition-travel\\LetterformZoom","transition\\transition-travel\\SharedElementMorph":"transition\\transition-travel\\SharedElementMorph","transition\\white-flash-logo-simplify-cut\\WhiteFlashLogoSimplifyCut":"transition\\white-flash-logo-simplify-cut\\WhiteFlashLogoSimplifyCut","transition\\wipe-transitions\\BlindsSlice":"transition\\wipe-transitions\\BlindsSlice","transition\\wipe-transitions\\ClockWipe":"transition\\wipe-transitions\\ClockWipe","typography\\blur-slide\\BlurSlide":"typography\\blur-slide\\BlurSlide","typography\\brace-expand\\BraceExpand":"typography\\brace-expand\\BraceExpand","typography\\brand-ink-open\\BrandInkOpen":"typography\\brand-ink-open\\BrandInkOpen","typography\\cel-flash-stomp\\CelFlashStomp":"typography\\cel-flash-stomp\\CelFlashStomp","typography\\countdown-arc-scatter\\CountdownArcScatter":"typography\\countdown-arc-scatter\\CountdownArcScatter","typography\\flying-words\\FlyingWords":"typography\\flying-words\\FlyingWords","typography\\glitch-cycle\\GlitchCycle":"typography\\glitch-cycle\\GlitchCycle","typography\\gradient-word-sweep\\GradientWordSweep":"typography\\gradient-word-sweep\\GradientWordSweep","typography\\lead-word-zoom-assemble\\LeadWordZoomAssemble":"typography\\lead-word-zoom-assemble\\LeadWordZoomAssemble","typography\\marker-underline-title\\MarkerUnderlineTitle":"typography\\marker-underline-title\\MarkerUnderlineTitle","typography\\outline-word-fill\\OutlineWordFill":"typography\\outline-word-fill\\OutlineWordFill","typography\\paper-title-card\\PaperTitleCard":"typography\\paper-title-card\\PaperTitleCard","typography\\pill-chip-slot-cycle-handled\\PillChipSlotCycleHandled":"typography\\pill-chip-slot-cycle-handled\\PillChipSlotCycleHandled","typography\\pill-slot-cycle\\PillSlotCycle":"typography\\pill-slot-cycle\\PillSlotCycle","typography\\scramble\\Scramble":"typography\\scramble\\Scramble","typography\\split-flap-title\\SplitFlapFlip":"typography\\split-flap-title\\SplitFlapFlip","typography\\text-column-converge\\TextColumnConverge":"typography\\text-column-converge\\TextColumnConverge","typography\\title-demote-to-label\\TitleDemoteToLabel":"typography\\title-demote-to-label\\TitleDemoteToLabel","typography\\type-assembly-moves\\LetterformDriftAssembly":"typography\\type-assembly-moves\\LetterformDriftAssembly","typography\\type-assembly-moves\\SplitTextStagger":"typography\\type-assembly-moves\\SplitTextStagger","typography\\type-assembly-moves\\TextOnPath":"typography\\type-assembly-moves\\TextOnPath","typography\\type-assembly-moves\\TrackingExpandReveal":"typography\\type-assembly-moves\\TrackingExpandReveal","typography\\type-entrance-moves\\LetterDropPhysics":"typography\\type-entrance-moves\\LetterDropPhysics","typography\\type-entrance-moves\\ScrambleDecode":"typography\\type-entrance-moves\\ScrambleDecode","typography\\type-rhythm-sync\\FontWeightPump":"typography\\type-rhythm-sync\\FontWeightPump","typography\\type-rhythm-sync\\KaraokeFillSync":"typography\\type-rhythm-sync\\KaraokeFillSync","typography\\typewriter-moves\\TerminalTypewriter":"typography\\typewriter-moves\\TerminalTypewriter","typography\\typewriter-moves\\TypewriterErrorRetype":"typography\\typewriter-moves\\TypewriterErrorRetype","typography\\typing-code-block\\TypingCodeBlock":"typography\\typing-code-block\\TypingCodeBlock","typography\\vertical-word-roll-blur-cycle\\VerticalWordRollBlurCycle":"typography\\vertical-word-roll-blur-cycle\\VerticalWordRollBlurCycle","typography\\word-relay-filmstrip\\WordRelayFilmstrip":"typography\\word-relay-filmstrip\\WordRelayFilmstrip","typography\\word-relay-geometry\\WordRelayGeometry":"typography\\word-relay-geometry\\WordRelayGeometry","ui-entrance\\avatar-bracket-carousel\\AvatarBracketCarousel":"ui-entrance\\avatar-bracket-carousel\\AvatarBracketCarousel","ui-entrance\\bezier-source-converge-merge\\BezierSourceConvergeMerge":"ui-entrance\\bezier-source-converge-merge\\BezierSourceConvergeMerge","ui-entrance\\card-stack\\CardStack":"ui-entrance\\card-stack\\CardStack","ui-entrance\\carousel-3d\\Carousel3D":"ui-entrance\\carousel-3d\\Carousel3D","ui-entrance\\cloner-depth-echo\\ClonerDepthEcho":"ui-entrance\\cloner-depth-echo\\ClonerDepthEcho","ui-entrance\\deck-deal-flyin\\DeckDealFlyin":"ui-entrance\\deck-deal-flyin\\DeckDealFlyin","ui-entrance\\doc-park-left-pill-deal\\DocParkLeftPillDeal":"ui-entrance\\doc-park-left-pill-deal\\DocParkLeftPillDeal","ui-entrance\\document-typewriter-reveal\\DocumentTypewriterReveal":"ui-entrance\\document-typewriter-reveal\\DocumentTypewriterReveal","ui-entrance\\draw-svg-trace\\DrawSvgTrace":"ui-entrance\\draw-svg-trace\\DrawSvgTrace","ui-entrance\\element-body-moves\\AxialStretch":"ui-entrance\\element-body-moves\\AxialStretch","ui-entrance\\element-body-moves\\ContactShadowLift":"ui-entrance\\element-body-moves\\ContactShadowLift","ui-entrance\\floating-glossy-label-pills\\FloatingGlossyLabelPills":"ui-entrance\\floating-glossy-label-pills\\FloatingGlossyLabelPills","ui-entrance\\integration-hub-map\\IntegrationHubMap":"ui-entrance\\integration-hub-map\\IntegrationHubMap","ui-entrance\\list-reveal\\ListReveal":"ui-entrance\\list-reveal\\ListReveal","ui-entrance\\list-stack-press\\ListStackPress":"ui-entrance\\list-stack-press\\ListStackPress","ui-entrance\\morph-from-primitive\\MorphFromPrimitive":"ui-entrance\\morph-from-primitive\\MorphFromPrimitive","ui-entrance\\neon-frame-forerun\\NeonFrameForerun":"ui-entrance\\neon-frame-forerun\\NeonFrameForerun","ui-entrance\\neon-frame-orbit-drop\\NeonFrameForerunOrbit":"ui-entrance\\neon-frame-orbit-drop\\NeonFrameForerunOrbit","ui-entrance\\page-waterfall-wall\\PageWaterfallWall":"ui-entrance\\page-waterfall-wall\\PageWaterfallWall","ui-entrance\\paper-craft-moves\\MaskingTapeSlap":"ui-entrance\\paper-craft-moves\\MaskingTapeSlap","ui-entrance\\paper-craft-moves\\PopupBookRise":"ui-entrance\\paper-craft-moves\\PopupBookRise","ui-entrance\\platform-hinge-rise\\PlatformHingeRise":"ui-entrance\\platform-hinge-rise\\PlatformHingeRise","ui-entrance\\product-card-progressive-assemble\\ProductCardProgressiveAssemble":"ui-entrance\\product-card-progressive-assemble\\ProductCardProgressiveAssemble","ui-entrance\\radial-wave\\RadialWave":"ui-entrance\\radial-wave\\RadialWave","ui-entrance\\research-card-stack-scroll\\ResearchCardStackScroll":"ui-entrance\\research-card-stack-scroll\\ResearchCardStackScroll","ui-entrance\\row-embed\\RowEmbed":"ui-entrance\\row-embed\\RowEmbed","ui-entrance\\runway-ground-skim\\RunwayGroundSkim":"ui-entrance\\runway-ground-skim\\RunwayGroundSkim","ui-entrance\\skeleton-reveal\\SkeletonReveal":"ui-entrance\\skeleton-reveal\\SkeletonReveal","ui-entrance\\svg-shape-morph\\SvgShapeMorph":"ui-entrance\\svg-shape-morph\\SvgShapeMorph","ui-entrance\\value-stagger-gradient\\ValueStaggerGradient":"ui-entrance\\value-stagger-gradient\\ValueStaggerGradient","ui-entrance\\wall-reveal-moves\\BentoLightUp":"ui-entrance\\wall-reveal-moves\\BentoLightUp","ui-entrance\\wall-reveal-moves\\GridWaveFlip":"ui-entrance\\wall-reveal-moves\\GridWaveFlip","ui-entrance\\wall-reveal-moves\\WireframeDrawOn":"ui-entrance\\wall-reveal-moves\\WireframeDrawOn"};
/** 中文原文 → 俄文（demo 卡名 / 分类 / 一句话，来自 workbench/i18n/ru/*.json，俄文界面按此显示） */
export const DEMO_TEXT_RU: Record<string, string> = {};
