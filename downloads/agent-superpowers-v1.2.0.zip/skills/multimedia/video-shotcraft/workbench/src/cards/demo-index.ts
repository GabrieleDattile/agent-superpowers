// 自动生成，勿手改：node scripts/gen-index.mjs
import type React from "react";
import { Basic3DScene as c0, BASIC_3D_SCENE_DURATION as d0 } from "@demos/camera\basic-3d-scene\Basic3DScene";
import { CrashImpactReal as c1, CRASHIMPACT_DUR as d1 } from "@demos/camera\crash-zoom-punch\CrashImpactReal";
import { CrashZoomReal as c2, CRASHZOOM_DUR as d2 } from "@demos/camera\crash-zoom-punch\CrashZoomReal";
import { CursorFlyover as c3, CURSOR_FLYOVER_DURATION as d3 } from "@demos/camera\cursor-flyover\CursorFlyover";
import { DollyZoomReal as c4, DOLLYZOOM_DUR as d4 } from "@demos/camera\depth-layer-moves\DollyZoomReal";
import { MultiplaneReal as c5, MULTIPLANE_DUR as d5 } from "@demos/camera\depth-layer-moves\MultiplaneReal";
import { GrazeFaceTour as c6 } from "@demos/camera\graze-face-tour\GrazeFaceTour";
import { OverheadTabletopDrop as c7 } from "@demos/camera\overhead-camera-moves\OverheadTabletopDrop";
import { TiltReveal as c8 } from "@demos/camera\overhead-camera-moves\TiltReveal";
import { DroneDiveLanding as c9 } from "@demos/camera\space-camera-moves\DroneDiveLanding";
import { ExplodedView as c10 } from "@demos/camera\space-camera-moves\ExplodedView";
import { SteepTiltGlide as c11 } from "@demos/camera\steep-tilt-glide\SteepTiltGlide";
import { BulletTimeFreezeOrbit as c12 } from "@demos/camera\tension-camera-moves\BulletTimeFreezeOrbit";
import { DutchRollToLevel as c13 } from "@demos/camera\tension-camera-moves\DutchRollToLevel";
import { PullBackIsolation as c14 } from "@demos/camera\tension-camera-moves\PullBackIsolation";
import { SlowPushIn as c15 } from "@demos/camera\tension-camera-moves\SlowPushIn";
import { Terminal3D as c16, TERMINAL_3D_DURATION as d16 } from "@demos/camera\terminal-3d\Terminal3D";
import { AvatarGridRadialBuildColorize as c17, AVATAR_GRID_RADIAL_BUILD_COLORIZE_DURATION as d17 } from "@demos/data\avatar-grid-radial-build-colorize\AvatarGridRadialBuildColorize";
import { BeforeAfterSliderScrub as c18 } from "@demos/data\before-after-slider-scrub\BeforeAfterSliderScrub";
import { AxisRescaleShockV2 as c19 } from "@demos/data\chart-live-moves\AxisRescaleShockV2";
import { OscilloscopeStreamV2 as c20 } from "@demos/data\chart-live-moves\OscilloscopeStreamV2";
import { UnitDotSwarmRegroupV2 as c21 } from "@demos/data\chart-live-moves\UnitDotSwarmRegroupV2";
import { CounterConfetti as c22, COUNTER_CONFETTI_DURATION as d22 } from "@demos/data\counter-confetti\CounterConfetti";
import { CycleGlassNodeMorph as c23, CYCLE_GLASS_NODE_MORPH_DURATION as d23 } from "@demos/data\cycle-glass-node-morph\CycleGlassNodeMorph";
import { NeedleSweepSelftest as c24 } from "@demos/data\gauge-readout-moves\NeedleSweepSelftest";
import { TapeScrollFixedPointer as c25 } from "@demos/data\gauge-readout-moves\TapeScrollFixedPointer";
import { HatchDepth as c26, HATCH_DEPTH_DURATION as d26 } from "@demos/data\hatch-depth\HatchDepth";
import { OdometerDigitRoll as c27 } from "@demos/data\odometer-digit-roll\OdometerDigitRoll";
import { ConfettiCrossfire as c28 } from "@demos/data\particle-celebrate-hits\ConfettiCrossfire";
import { CounterTickSparks as c29 } from "@demos/data\particle-celebrate-hits\CounterTickSparks";
import { ParticleSandFill as c30 } from "@demos/data\particle-sand-fill\ParticleSandFill";
import { RingDiagramAnnotationReveal as c31, RING_DIAGRAM_ANNOTATION_REVEAL_DURATION as d31 } from "@demos/data\ring-diagram-annotation-reveal\RingDiagramAnnotationReveal";
import { BrakeReticleLock as c32 } from "@demos/data\scroll-brake-moves\BrakeReticleLock";
import { ChangelogScrollBrake as c33 } from "@demos/data\scroll-brake-moves\ChangelogScrollBrake";
import { TimelineTravel as c34 } from "@demos/data\timeline-travel\TimelineTravel";
import { AssembleThenTypeFlyin as c35, ASSEMBLE_THEN_TYPE_FLYIN_DURATION as d35 } from "@demos/effects\assemble-then-type-flyin\AssembleThenTypeFlyin";
import { AuroraBloomBgFlip as c36, AURORA_BLOOM_BG_FLIP_DURATION as d36 } from "@demos/effects\aurora-bloom-bg-flip\AuroraBloomBgFlip";
import { BrandFrameSnap as c37 } from "@demos/effects\brand-frame-snap\BrandFrameSnap";
import { DashboardGlowHighlightPill as c38, DASHBOARD_GLOW_HIGHLIGHT_PILL_DURATION as d38 } from "@demos/effects\dashboard-glow-highlight-pill\DashboardGlowHighlightPill";
import { LineUnfoldPanel as c39 } from "@demos/effects\fui-hud-moves\LineUnfoldPanel";
import { ReticleLockOn as c40 } from "@demos/effects\fui-hud-moves\ReticleLockOn";
import { FlylineArc as c41 } from "@demos/effects\glow-flyline-moves\FlylineArc";
import { GlowOrbAmbient as c42 } from "@demos/effects\glow-flyline-moves\GlowOrbAmbient";
import { OrbFlylineRelay as c43 } from "@demos/effects\glow-flyline-moves\OrbFlylineRelay";
import { AttentionBounce as c44 } from "@demos/effects\icon-performance-moves\AttentionBounce";
import { PopBurstConfirm as c45 } from "@demos/effects\icon-performance-moves\PopBurstConfirm";
import { AnimeImpact as c46 } from "@demos/effects\impact-feedback\AnimeImpact";
import { HitCounter as c47 } from "@demos/effects\impact-feedback\HitCounter";
import { HalationBloom as c48 } from "@demos/effects\light-play-moves\HalationBloom";
import { SheenSweepRetry as c49 } from "@demos/effects\light-play-moves\SheenSweepRetry";
import { SpotlightSweepReveal as c50 } from "@demos/effects\light-play-moves\SpotlightSweepReveal";
import { LineBoil as c51 } from "@demos/effects\line-boil\LineBoil";
import { RadialRipplePhoneChips as c52, RADIAL_RIPPLE_PHONE_CHIPS_DURATION as d52 } from "@demos/effects\radial-ripple-phone-chips\RadialRipplePhoneChips";
import { RisoBeatPump as c53 } from "@demos/effects\riso-print-hits\RisoBeatPump";
import { RisoMisregistrationHit as c54 } from "@demos/effects\riso-print-hits\RisoMisregistrationHit";
import { ScanBracketSweep as c55, SCAN_BRACKET_SWEEP_DURATION as d55 } from "@demos/effects\scan-bracket-sweep\ScanBracketSweep";
import { ScanlineAnnotateFocus as c56, SCANLINE_ANNOTATE_FOCUS_DURATION as d56 } from "@demos/effects\scanline-annotate-focus\ScanlineAnnotateFocus";
import { ScanlineAssembleFlyin as c57, SCANLINE_ASSEMBLE_FLYIN_DURATION as d57 } from "@demos/effects\scanline-assemble-flyin\ScanlineAssembleFlyin";
import { ImpactBurstKit as c58 } from "@demos/effects\slam-entrance-moves\ImpactBurstKit";
import { KanadaPerspectiveSnap as c59 } from "@demos/effects\slam-entrance-moves\KanadaPerspectiveSnap";
import { ScoreSlam as c60 } from "@demos/effects\slam-entrance-moves\ScoreSlam";
import { CornerSpotlightReveal as c61 } from "@demos/effects\spotlight-sweep-moves\CornerSpotlightReveal";
import { GlowWakeSleepPanel as c62 } from "@demos/effects\spotlight-sweep-moves\GlowWakeSleepPanel";
import { SlideSpotlightPan as c63 } from "@demos/effects\spotlight-sweep-moves\SlideSpotlightPan";
import { StreamResponse as c64 } from "@demos/interaction\ai-stream-response\StreamResponse";
import { AutolayoutGapDial as c65 } from "@demos/interaction\autolayout-gap-dial\AutolayoutGapDial";
import { DiagramCascadeBuild as c66 } from "@demos/interaction\canvas-materialize-moves\DiagramCascadeBuild";
import { PanelToCanvasMaterialize as c67 } from "@demos/interaction\canvas-materialize-moves\PanelToCanvasMaterialize";
import { ChipGridSingleSelectBlackout as c68, CHIP_GRID_SINGLE_SELECT_BLACKOUT_DURATION as d68 } from "@demos/interaction\chip-grid-single-select-blackout\ChipGridSingleSelectBlackout";
import { ChipLiftToUserPill as c69, CHIP_LIFT_TO_USER_PILL_DURATION as d69 } from "@demos/interaction\chip-lift-to-user-pill\ChipLiftToUserPill";
import { CursorCastEnsemble as c70 } from "@demos/interaction\collab-cursor-moves\CursorCastEnsemble";
import { CursorDialogueDuet as c71 } from "@demos/interaction\collab-cursor-moves\CursorDialogueDuet";
import { CommandPaletteSummon as c72 } from "@demos/interaction\command-palette-summon\CommandPaletteSummon";
import { GlassPillDictationTyping as c73, GLASS_PILL_DICTATION_TYPING_DURATION as d73 } from "@demos/interaction\glass-pill-dictation-typing\GlassPillDictationTyping";
import { HashtagToPillMaterialize as c74 } from "@demos/interaction\hashtag-to-pill-materialize\HashtagToPillMaterialize";
import { CursorPerformancePunchIn as c75 } from "@demos/interaction\input-trigger-moves\CursorPerformancePunchIn";
import { KeycapSmashCut as c76 } from "@demos/interaction\input-trigger-moves\KeycapSmashCut";
import { PickerCarouselFeatureCycle as c77, PICKER_CAROUSEL_FEATURE_CYCLE_DURATION as d77 } from "@demos/interaction\picker-carousel-feature-cycle\PickerCarouselFeatureCycle";
import { SegmentedThumbHero as c78 } from "@demos/interaction\segmented-thumb-hero\SegmentedThumbHero";
import { PaletteThemeRipple as c79 } from "@demos/interaction\theme-switch-moves\PaletteThemeRipple";
import { ThemeSweepToggle as c80 } from "@demos/interaction\theme-switch-moves\ThemeSweepToggle";
import { TypeAndFilter as c81, TYPE_AND_FILTER_DURATION as d81 } from "@demos/interaction\type-and-filter\TypeAndFilter";
import { VoiceWaveformLive as c82 } from "@demos/interaction\voice-waveform-live\VoiceWaveformLive";
import { CraneRiseReveal as c83 } from "@demos/opening\crane-rise-reveal\CraneRiseReveal";
import { DatavizLandscapeOpen as c84 } from "@demos/opening\dataviz-landscape-open\DatavizLandscapeOpen";
import { Fracture as c85, FRACTURE_DURATION as d85 } from "@demos/opening\fracture\Fracture";
import { IconFieldColorize as c86 } from "@demos/opening\icon-field-colorize\IconFieldColorize";
import { LetterspaceMaterialize as c87 } from "@demos/opening\letterspace-materialize\LetterspaceMaterialize";
import { MagicianCardFlourish as c88 } from "@demos/opening\magician-card-flourish\MagicianCardFlourish";
import { OrbitRingTitleOpen as c89, ORBIT_RING_TITLE_OPEN_DURATION as d89 } from "@demos/opening\orbit-ring-title-open\OrbitRingTitleOpen";
import { SpotlightHeroCard as c90, SPOTLIGHT_HERO_CARD_DURATION as d90 } from "@demos/opening\spotlight-hero-card\SpotlightHeroCard";
import { StrokeSegmentBuild as c91 } from "@demos/opening\stroke-segment-build\StrokeSegmentBuild";
import { TextAsMask as c92 } from "@demos/opening\text-as-mask\TextAsMask";
import { LogoStingButton as c93 } from "@demos/outro\edit-hook-moves\LogoStingButton";
import { GrainDissolve as c94, GRAIN_DISSOLVE_DURATION as d94 } from "@demos/outro\grain-dissolve\GrainDissolve";
import { LogoShrinkWordmarkLockup as c95, LOGO_SHRINK_WORDMARK_LOCKUP_DURATION as d95 } from "@demos/outro\logo-shrink-wordmark-lockup\LogoShrinkWordmarkLockup";
import { NeonTripleMarquee as c96 } from "@demos/outro\neon-triple-marquee\NeonTripleMarquee";
import { OutroGroupPhotoLaunch as c97, OUTRO_GROUP_PHOTO_LAUNCH_DURATION as d97 } from "@demos/outro\outro-group-photo-launch\OutroGroupPhotoLaunch";
import { UiStripAwayOutro as c98 } from "@demos/outro\ui-strip-away-outro\UiStripAwayOutro";
import { IconFlipBloomLogo as c99 } from "@demos/outro\ui-to-brand-morph\IconFlipBloomLogo";
import { InputMorphsIntoLogo as c100 } from "@demos/outro\ui-to-brand-morph\InputMorphsIntoLogo";
import { BeatCutAccelerando as c101 } from "@demos/rhythm\beat-cut-moves\BeatCutAccelerando";
import { PaparazziFlash as c102 } from "@demos/rhythm\beat-cut-moves\PaparazziFlash";
import { BeatStepListThemeCycle as c103 } from "@demos/rhythm\beat-step-list-theme-cycle\BeatStepListThemeCycle";
import { DominoCascade as c104 } from "@demos/rhythm\montage-rhythm-moves\DominoCascade";
import { DropBlackoutSlam as c105 } from "@demos/rhythm\montage-rhythm-moves\DropBlackoutSlam";
import { WrightTripleCut as c106 } from "@demos/rhythm\montage-rhythm-moves\WrightTripleCut";
import { ComicPanelSplit as c107 } from "@demos/rhythm\panel-grid-moves\ComicPanelSplit";
import { FlipGridReflow as c108 } from "@demos/rhythm\panel-grid-moves\FlipGridReflow";
import { GridFlashMosaic as c109 } from "@demos/rhythm\panel-grid-moves\GridFlashMosaic";
import { QuadSplitParallelScenes as c110, QUAD_SPLIT_PARALLEL_SCENES_DURATION as d110 } from "@demos/rhythm\quad-split-parallel-scenes\QuadSplitParallelScenes";
import { JumpCutPunchIn as c111 } from "@demos/rhythm\rhythm-interrupt-moves\JumpCutPunchIn";
import { StrobeBlackFrames as c112 } from "@demos/rhythm\rhythm-interrupt-moves\StrobeBlackFrames";
import { SakugaTimingShift as c113 } from "@demos/rhythm\sakuga-timing-shift\SakugaTimingShift";
import { SmearMultiples as c114 } from "@demos/rhythm\smear-multiples\SmearMultiples";
import { SpectrumMorphUi as c115 } from "@demos/rhythm\spectrum-morph-ui\SpectrumMorphUi";
import { FreezeAnnotateReal as c116, FREEZEANNOTATE_DUR as d116 } from "@demos/rhythm\speed-ramp-freeze\FreezeAnnotateReal";
import { SpeedRampReal as c117, SPEEDRAMP_DUR as d117 } from "@demos/rhythm\speed-ramp-freeze\SpeedRampReal";
import { CardFootageCadence as c118 } from "@demos/rhythm\trailer-grammar-moves\CardFootageCadence";
import { SmashCut as c119 } from "@demos/rhythm\trailer-grammar-moves\SmashCut";
import { TrailerBumper as c120 } from "@demos/rhythm\trailer-grammar-moves\TrailerBumper";
import { BottomPushStackWipe as c121 } from "@demos/transition\bottom-push-stack-wipe\BottomPushStackWipe";
import { BubbleSwarmTakeover as c122 } from "@demos/transition\bubble-swarm-takeover\BubbleSwarmTakeover";
import { CardFlipReveal as c123 } from "@demos/transition\card-flip-reveal\CardFlipReveal";
import { CardFlockTumble as c124 } from "@demos/transition\card-flock-tumble\CardFlockTumble";
import { CircleMatchIris as c125 } from "@demos/transition\circle-match-iris\CircleMatchIris";
import { ColorBlockStepWipe as c126 } from "@demos/transition\color-block-step-wipe\ColorBlockStepWipe";
import { CubeNavigation as c127, CUBE_NAVIGATION_DURATION as d127 } from "@demos/transition\cube-navigation\CubeNavigation";
import { GradientTransition as c128, GRADIENT_TRANSITION_DURATION as d128 } from "@demos/transition\gradient-transition\GradientTransition";
import { LineCarryTransition as c129 } from "@demos/transition\line-carry-transition\LineCarryTransition";
import { MosaicReframe as c130, MOSAIC_REFRAME_DURATION as d130 } from "@demos/transition\mosaic-reframe\MosaicReframe";
import { BarnDoorSplit as c131 } from "@demos/transition\page-turn-transitions\BarnDoorSplit";
import { CubeRotate as c132 } from "@demos/transition\page-turn-transitions\CubeRotate";
import { PaperPlaneMessenger as c133 } from "@demos/transition\paper-plane-messenger\PaperPlaneMessenger";
import { InkBleedReveal as c134 } from "@demos/transition\print-texture-transitions\InkBleedReveal";
import { BlackCardTransition as c135, BLACKCARD_DUR as d135 } from "@demos/transition\shot-transitions\BlackCardTransition";
import { DarkTunnelTransition as c136, DARKTUNNEL_DUR as d136 } from "@demos/transition\shot-transitions\DarkTunnelTransition";
import { FocusHandoffTransition as c137, FOCUSHANDOFF_DUR as d137 } from "@demos/transition\shot-transitions\FocusHandoffTransition";
import { MaskWipeReal as c138, MASKWIPE_DUR as d138 } from "@demos/transition\shot-transitions\MaskWipeReal";
import { PortalWipeV2 as c139 } from "@demos/transition\shot-transitions\PortalWipeV2";
import { WhipBrakeReal as c140, WHIPBRAKE_DUR as d140 } from "@demos/transition\shot-transitions\WhipBrakeReal";
import { WhipPanReal as c141, WHIPPAN_DUR as d141 } from "@demos/transition\shot-transitions\WhipPanReal";
import { GlitchDisplace as c142 } from "@demos/transition\tear-streak-transitions\GlitchDisplace";
import { InvisibleCut as c143 } from "@demos/transition\transition-hidden-cut\InvisibleCut";
import { LightLeakBurn as c144 } from "@demos/transition\transition-hidden-cut\LightLeakBurn";
import { VersusSlam as c145 } from "@demos/transition\transition-hidden-cut\VersusSlam";
import { LetterformZoom as c146 } from "@demos/transition\transition-travel\LetterformZoom";
import { SharedElementMorph as c147 } from "@demos/transition\transition-travel\SharedElementMorph";
import { WhiteFlashLogoSimplifyCut as c148, WHITE_FLASH_LOGO_SIMPLIFY_CUT_DURATION as d148 } from "@demos/transition\white-flash-logo-simplify-cut\WhiteFlashLogoSimplifyCut";
import { BlindsSlice as c149 } from "@demos/transition\wipe-transitions\BlindsSlice";
import { ClockWipe as c150 } from "@demos/transition\wipe-transitions\ClockWipe";
import { BlurSlide as c151, BLUR_SLIDE_DURATION as d151 } from "@demos/typography\blur-slide\BlurSlide";
import { BraceExpand as c152, BRACE_EXPAND_DURATION as d152 } from "@demos/typography\brace-expand\BraceExpand";
import { BrandInkOpen as c153, BRAND_INK_OPEN_DURATION as d153 } from "@demos/typography\brand-ink-open\BrandInkOpen";
import { CelFlashStomp as c154 } from "@demos/typography\cel-flash-stomp\CelFlashStomp";
import { CountdownArcScatter as c155, COUNTDOWN_ARC_SCATTER_DURATION as d155 } from "@demos/typography\countdown-arc-scatter\CountdownArcScatter";
import { FlyingWords as c156, FLYING_WORDS_DURATION as d156 } from "@demos/typography\flying-words\FlyingWords";
import { GlitchCycle as c157, GLITCH_CYCLE_DURATION as d157 } from "@demos/typography\glitch-cycle\GlitchCycle";
import { GradientWordSweep as c158 } from "@demos/typography\gradient-word-sweep\GradientWordSweep";
import { LeadWordZoomAssemble as c159, LEAD_WORD_ZOOM_ASSEMBLE_DURATION as d159 } from "@demos/typography\lead-word-zoom-assemble\LeadWordZoomAssemble";
import { MarkerUnderlineTitle as c160 } from "@demos/typography\marker-underline-title\MarkerUnderlineTitle";
import { OutlineWordFill as c161, OUTLINE_WORD_FILL_DURATION as d161 } from "@demos/typography\outline-word-fill\OutlineWordFill";
import { PaperTitleCard as c162, PAPER_TITLE_CARD_DURATION as d162 } from "@demos/typography\paper-title-card\PaperTitleCard";
import { PillChipSlotCycleHandled as c163, PILL_CHIP_SLOT_CYCLE_HANDLED_DURATION as d163 } from "@demos/typography\pill-chip-slot-cycle-handled\PillChipSlotCycleHandled";
import { PillSlotCycle as c164 } from "@demos/typography\pill-slot-cycle\PillSlotCycle";
import { Scramble as c165, SCRAMBLE_DURATION as d165 } from "@demos/typography\scramble\Scramble";
import { SplitFlapFlip as c166 } from "@demos/typography\split-flap-title\SplitFlapFlip";
import { TextColumnConverge as c167 } from "@demos/typography\text-column-converge\TextColumnConverge";
import { TitleDemoteToLabel as c168 } from "@demos/typography\title-demote-to-label\TitleDemoteToLabel";
import { LetterformDriftAssembly as c169 } from "@demos/typography\type-assembly-moves\LetterformDriftAssembly";
import { SplitTextStagger as c170 } from "@demos/typography\type-assembly-moves\SplitTextStagger";
import { TextOnPath as c171 } from "@demos/typography\type-assembly-moves\TextOnPath";
import { TrackingExpandReveal as c172 } from "@demos/typography\type-assembly-moves\TrackingExpandReveal";
import { LetterDropPhysics as c173 } from "@demos/typography\type-entrance-moves\LetterDropPhysics";
import { ScrambleDecode as c174 } from "@demos/typography\type-entrance-moves\ScrambleDecode";
import { FontWeightPump as c175 } from "@demos/typography\type-rhythm-sync\FontWeightPump";
import { KaraokeFillSync as c176 } from "@demos/typography\type-rhythm-sync\KaraokeFillSync";
import { TerminalTypewriter as c177 } from "@demos/typography\typewriter-moves\TerminalTypewriter";
import { TypewriterErrorRetype as c178 } from "@demos/typography\typewriter-moves\TypewriterErrorRetype";
import { TypingCodeBlock as c179, TYPING_CODE_BLOCK_DURATION as d179 } from "@demos/typography\typing-code-block\TypingCodeBlock";
import { VerticalWordRollBlurCycle as c180, VERTICAL_WORD_ROLL_BLUR_CYCLE_DURATION as d180 } from "@demos/typography\vertical-word-roll-blur-cycle\VerticalWordRollBlurCycle";
import { WordRelayFilmstrip as c181 } from "@demos/typography\word-relay-filmstrip\WordRelayFilmstrip";
import { WordRelayGeometry as c182, WORD_RELAY_GEOMETRY_DURATION as d182 } from "@demos/typography\word-relay-geometry\WordRelayGeometry";
import { AvatarBracketCarousel as c183, AVATAR_BRACKET_CAROUSEL_DURATION as d183 } from "@demos/ui-entrance\avatar-bracket-carousel\AvatarBracketCarousel";
import { BezierSourceConvergeMerge as c184, BEZIER_SOURCE_CONVERGE_MERGE_DURATION as d184 } from "@demos/ui-entrance\bezier-source-converge-merge\BezierSourceConvergeMerge";
import { CardStack as c185, CARD_STACK_DURATION as d185 } from "@demos/ui-entrance\card-stack\CardStack";
import { Carousel3D as c186, CAROUSEL_3D_DURATION as d186 } from "@demos/ui-entrance\carousel-3d\Carousel3D";
import { ClonerDepthEcho as c187 } from "@demos/ui-entrance\cloner-depth-echo\ClonerDepthEcho";
import { DeckDealFlyin as c188, DECK_DEAL_FLYIN_DURATION as d188 } from "@demos/ui-entrance\deck-deal-flyin\DeckDealFlyin";
import { DocParkLeftPillDeal as c189, DOC_PARK_LEFT_PILL_DEAL_DURATION as d189 } from "@demos/ui-entrance\doc-park-left-pill-deal\DocParkLeftPillDeal";
import { DocumentTypewriterReveal as c190, DOCUMENT_TYPEWRITER_REVEAL_DURATION as d190 } from "@demos/ui-entrance\document-typewriter-reveal\DocumentTypewriterReveal";
import { DrawSvgTrace as c191 } from "@demos/ui-entrance\draw-svg-trace\DrawSvgTrace";
import { AxialStretch as c192 } from "@demos/ui-entrance\element-body-moves\AxialStretch";
import { ContactShadowLift as c193 } from "@demos/ui-entrance\element-body-moves\ContactShadowLift";
import { FloatingGlossyLabelPills as c194, FLOATING_GLOSSY_LABEL_PILLS_DURATION as d194 } from "@demos/ui-entrance\floating-glossy-label-pills\FloatingGlossyLabelPills";
import { IntegrationHubMap as c195 } from "@demos/ui-entrance\integration-hub-map\IntegrationHubMap";
import { ListReveal as c196, LIST_REVEAL_DURATION as d196 } from "@demos/ui-entrance\list-reveal\ListReveal";
import { ListStackPress as c197, LIST_STACK_PRESS_DURATION as d197 } from "@demos/ui-entrance\list-stack-press\ListStackPress";
import { MorphFromPrimitive as c198 } from "@demos/ui-entrance\morph-from-primitive\MorphFromPrimitive";
import { NeonFrameForerun as c199 } from "@demos/ui-entrance\neon-frame-forerun\NeonFrameForerun";
import { NeonFrameForerunOrbit as c200 } from "@demos/ui-entrance\neon-frame-orbit-drop\NeonFrameForerunOrbit";
import { PageWaterfallWall as c201 } from "@demos/ui-entrance\page-waterfall-wall\PageWaterfallWall";
import { MaskingTapeSlap as c202 } from "@demos/ui-entrance\paper-craft-moves\MaskingTapeSlap";
import { PopupBookRise as c203 } from "@demos/ui-entrance\paper-craft-moves\PopupBookRise";
import { PlatformHingeRise as c204, PLATFORM_HINGE_RISE_DURATION as d204 } from "@demos/ui-entrance\platform-hinge-rise\PlatformHingeRise";
import { ProductCardProgressiveAssemble as c205, PRODUCT_CARD_PROGRESSIVE_ASSEMBLE_DURATION as d205 } from "@demos/ui-entrance\product-card-progressive-assemble\ProductCardProgressiveAssemble";
import { RadialWave as c206, RADIAL_WAVE_DURATION as d206 } from "@demos/ui-entrance\radial-wave\RadialWave";
import { ResearchCardStackScroll as c207, RESEARCH_CARD_STACK_SCROLL_DURATION as d207 } from "@demos/ui-entrance\research-card-stack-scroll\ResearchCardStackScroll";
import { RowEmbed as c208, ROW_EMBED_DURATION as d208 } from "@demos/ui-entrance\row-embed\RowEmbed";
import { RunwayGroundSkim as c209 } from "@demos/ui-entrance\runway-ground-skim\RunwayGroundSkim";
import { SkeletonReveal as c210 } from "@demos/ui-entrance\skeleton-reveal\SkeletonReveal";
import { SvgShapeMorph as c211, SVG_SHAPE_MORPH_DURATION as d211 } from "@demos/ui-entrance\svg-shape-morph\SvgShapeMorph";
import { ValueStaggerGradient as c212, VALUE_STAGGER_GRADIENT_DURATION as d212 } from "@demos/ui-entrance\value-stagger-gradient\ValueStaggerGradient";
import { BentoLightUp as c213 } from "@demos/ui-entrance\wall-reveal-moves\BentoLightUp";
import { GridWaveFlip as c214 } from "@demos/ui-entrance\wall-reveal-moves\GridWaveFlip";
import { WireframeDrawOn as c215 } from "@demos/ui-entrance\wall-reveal-moves\WireframeDrawOn";

export type DemoModule = {
  stem: string;
  slug: string;
  component: React.ComponentType<Record<string, unknown>>;
  duration: number;
  /** 时长来源：export=demo 自己导出 / card=镜头卡 md / gallery=画廊 / inline=文件内常量 / default=缺省 150f */
  durationSource: "export" | "card" | "gallery" | "inline" | "default";
};

export const DEMO_MODULES: DemoModule[] = [
  { stem: "Basic3DScene", slug: "undefined", component: c0 as unknown as React.ComponentType<Record<string, unknown>>, duration: d0, durationSource: "export" },
  { stem: "CrashImpactReal", slug: "undefined", component: c1 as unknown as React.ComponentType<Record<string, unknown>>, duration: d1, durationSource: "export" },
  { stem: "CrashZoomReal", slug: "undefined", component: c2 as unknown as React.ComponentType<Record<string, unknown>>, duration: d2, durationSource: "export" },
  { stem: "CursorFlyover", slug: "undefined", component: c3 as unknown as React.ComponentType<Record<string, unknown>>, duration: d3, durationSource: "export" },
  { stem: "DollyZoomReal", slug: "undefined", component: c4 as unknown as React.ComponentType<Record<string, unknown>>, duration: d4, durationSource: "export" },
  { stem: "MultiplaneReal", slug: "undefined", component: c5 as unknown as React.ComponentType<Record<string, unknown>>, duration: d5, durationSource: "export" },
  { stem: "GrazeFaceTour", slug: "undefined", component: c6 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "OverheadTabletopDrop", slug: "undefined", component: c7 as unknown as React.ComponentType<Record<string, unknown>>, duration: 55, durationSource: "inline" },
  { stem: "TiltReveal", slug: "undefined", component: c8 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "DroneDiveLanding", slug: "undefined", component: c9 as unknown as React.ComponentType<Record<string, unknown>>, duration: 45, durationSource: "inline" },
  { stem: "ExplodedView", slug: "undefined", component: c10 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SteepTiltGlide", slug: "undefined", component: c11 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "BulletTimeFreezeOrbit", slug: "undefined", component: c12 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "DutchRollToLevel", slug: "undefined", component: c13 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "PullBackIsolation", slug: "undefined", component: c14 as unknown as React.ComponentType<Record<string, unknown>>, duration: 16, durationSource: "inline" },
  { stem: "SlowPushIn", slug: "undefined", component: c15 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "Terminal3D", slug: "undefined", component: c16 as unknown as React.ComponentType<Record<string, unknown>>, duration: d16, durationSource: "export" },
  { stem: "AvatarGridRadialBuildColorize", slug: "undefined", component: c17 as unknown as React.ComponentType<Record<string, unknown>>, duration: d17, durationSource: "export" },
  { stem: "BeforeAfterSliderScrub", slug: "undefined", component: c18 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "AxisRescaleShockV2", slug: "undefined", component: c19 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "OscilloscopeStreamV2", slug: "undefined", component: c20 as unknown as React.ComponentType<Record<string, unknown>>, duration: 112, durationSource: "inline" },
  { stem: "UnitDotSwarmRegroupV2", slug: "undefined", component: c21 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CounterConfetti", slug: "undefined", component: c22 as unknown as React.ComponentType<Record<string, unknown>>, duration: d22, durationSource: "export" },
  { stem: "CycleGlassNodeMorph", slug: "undefined", component: c23 as unknown as React.ComponentType<Record<string, unknown>>, duration: d23, durationSource: "export" },
  { stem: "NeedleSweepSelftest", slug: "undefined", component: c24 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TapeScrollFixedPointer", slug: "undefined", component: c25 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "HatchDepth", slug: "undefined", component: c26 as unknown as React.ComponentType<Record<string, unknown>>, duration: d26, durationSource: "export" },
  { stem: "OdometerDigitRoll", slug: "undefined", component: c27 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "ConfettiCrossfire", slug: "undefined", component: c28 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CounterTickSparks", slug: "undefined", component: c29 as unknown as React.ComponentType<Record<string, unknown>>, duration: 78, durationSource: "inline" },
  { stem: "ParticleSandFill", slug: "undefined", component: c30 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "RingDiagramAnnotationReveal", slug: "undefined", component: c31 as unknown as React.ComponentType<Record<string, unknown>>, duration: d31, durationSource: "export" },
  { stem: "BrakeReticleLock", slug: "undefined", component: c32 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "ChangelogScrollBrake", slug: "undefined", component: c33 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TimelineTravel", slug: "undefined", component: c34 as unknown as React.ComponentType<Record<string, unknown>>, duration: 104, durationSource: "inline" },
  { stem: "AssembleThenTypeFlyin", slug: "undefined", component: c35 as unknown as React.ComponentType<Record<string, unknown>>, duration: d35, durationSource: "export" },
  { stem: "AuroraBloomBgFlip", slug: "undefined", component: c36 as unknown as React.ComponentType<Record<string, unknown>>, duration: d36, durationSource: "export" },
  { stem: "BrandFrameSnap", slug: "undefined", component: c37 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "DashboardGlowHighlightPill", slug: "undefined", component: c38 as unknown as React.ComponentType<Record<string, unknown>>, duration: d38, durationSource: "export" },
  { stem: "LineUnfoldPanel", slug: "undefined", component: c39 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "ReticleLockOn", slug: "undefined", component: c40 as unknown as React.ComponentType<Record<string, unknown>>, duration: 24, durationSource: "inline" },
  { stem: "FlylineArc", slug: "undefined", component: c41 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "GlowOrbAmbient", slug: "undefined", component: c42 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "OrbFlylineRelay", slug: "undefined", component: c43 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "AttentionBounce", slug: "undefined", component: c44 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "PopBurstConfirm", slug: "undefined", component: c45 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "AnimeImpact", slug: "undefined", component: c46 as unknown as React.ComponentType<Record<string, unknown>>, duration: 30, durationSource: "inline" },
  { stem: "HitCounter", slug: "undefined", component: c47 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "HalationBloom", slug: "undefined", component: c48 as unknown as React.ComponentType<Record<string, unknown>>, duration: 17, durationSource: "inline" },
  { stem: "SheenSweepRetry", slug: "undefined", component: c49 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SpotlightSweepReveal", slug: "undefined", component: c50 as unknown as React.ComponentType<Record<string, unknown>>, duration: 110, durationSource: "inline" },
  { stem: "LineBoil", slug: "undefined", component: c51 as unknown as React.ComponentType<Record<string, unknown>>, duration: 105, durationSource: "inline" },
  { stem: "RadialRipplePhoneChips", slug: "undefined", component: c52 as unknown as React.ComponentType<Record<string, unknown>>, duration: d52, durationSource: "export" },
  { stem: "RisoBeatPump", slug: "undefined", component: c53 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "RisoMisregistrationHit", slug: "undefined", component: c54 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "ScanBracketSweep", slug: "undefined", component: c55 as unknown as React.ComponentType<Record<string, unknown>>, duration: d55, durationSource: "export" },
  { stem: "ScanlineAnnotateFocus", slug: "undefined", component: c56 as unknown as React.ComponentType<Record<string, unknown>>, duration: d56, durationSource: "export" },
  { stem: "ScanlineAssembleFlyin", slug: "undefined", component: c57 as unknown as React.ComponentType<Record<string, unknown>>, duration: d57, durationSource: "export" },
  { stem: "ImpactBurstKit", slug: "undefined", component: c58 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "KanadaPerspectiveSnap", slug: "undefined", component: c59 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "ScoreSlam", slug: "undefined", component: c60 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CornerSpotlightReveal", slug: "undefined", component: c61 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "GlowWakeSleepPanel", slug: "undefined", component: c62 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SlideSpotlightPan", slug: "undefined", component: c63 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "StreamResponse", slug: "undefined", component: c64 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "AutolayoutGapDial", slug: "undefined", component: c65 as unknown as React.ComponentType<Record<string, unknown>>, duration: 52, durationSource: "inline" },
  { stem: "DiagramCascadeBuild", slug: "undefined", component: c66 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "PanelToCanvasMaterialize", slug: "undefined", component: c67 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "ChipGridSingleSelectBlackout", slug: "undefined", component: c68 as unknown as React.ComponentType<Record<string, unknown>>, duration: d68, durationSource: "export" },
  { stem: "ChipLiftToUserPill", slug: "undefined", component: c69 as unknown as React.ComponentType<Record<string, unknown>>, duration: d69, durationSource: "export" },
  { stem: "CursorCastEnsemble", slug: "undefined", component: c70 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CursorDialogueDuet", slug: "undefined", component: c71 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CommandPaletteSummon", slug: "undefined", component: c72 as unknown as React.ComponentType<Record<string, unknown>>, duration: 104, durationSource: "inline" },
  { stem: "GlassPillDictationTyping", slug: "undefined", component: c73 as unknown as React.ComponentType<Record<string, unknown>>, duration: d73, durationSource: "export" },
  { stem: "HashtagToPillMaterialize", slug: "undefined", component: c74 as unknown as React.ComponentType<Record<string, unknown>>, duration: 80, durationSource: "inline" },
  { stem: "CursorPerformancePunchIn", slug: "undefined", component: c75 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "KeycapSmashCut", slug: "undefined", component: c76 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "PickerCarouselFeatureCycle", slug: "undefined", component: c77 as unknown as React.ComponentType<Record<string, unknown>>, duration: d77, durationSource: "export" },
  { stem: "SegmentedThumbHero", slug: "undefined", component: c78 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "PaletteThemeRipple", slug: "undefined", component: c79 as unknown as React.ComponentType<Record<string, unknown>>, duration: 95, durationSource: "inline" },
  { stem: "ThemeSweepToggle", slug: "undefined", component: c80 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TypeAndFilter", slug: "undefined", component: c81 as unknown as React.ComponentType<Record<string, unknown>>, duration: d81, durationSource: "export" },
  { stem: "VoiceWaveformLive", slug: "undefined", component: c82 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CraneRiseReveal", slug: "undefined", component: c83 as unknown as React.ComponentType<Record<string, unknown>>, duration: 120, durationSource: "inline" },
  { stem: "DatavizLandscapeOpen", slug: "undefined", component: c84 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "Fracture", slug: "undefined", component: c85 as unknown as React.ComponentType<Record<string, unknown>>, duration: d85, durationSource: "export" },
  { stem: "IconFieldColorize", slug: "undefined", component: c86 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "LetterspaceMaterialize", slug: "undefined", component: c87 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "MagicianCardFlourish", slug: "undefined", component: c88 as unknown as React.ComponentType<Record<string, unknown>>, duration: 12, durationSource: "inline" },
  { stem: "OrbitRingTitleOpen", slug: "undefined", component: c89 as unknown as React.ComponentType<Record<string, unknown>>, duration: d89, durationSource: "export" },
  { stem: "SpotlightHeroCard", slug: "undefined", component: c90 as unknown as React.ComponentType<Record<string, unknown>>, duration: d90, durationSource: "export" },
  { stem: "StrokeSegmentBuild", slug: "undefined", component: c91 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TextAsMask", slug: "undefined", component: c92 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "LogoStingButton", slug: "undefined", component: c93 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "GrainDissolve", slug: "undefined", component: c94 as unknown as React.ComponentType<Record<string, unknown>>, duration: d94, durationSource: "export" },
  { stem: "LogoShrinkWordmarkLockup", slug: "undefined", component: c95 as unknown as React.ComponentType<Record<string, unknown>>, duration: d95, durationSource: "export" },
  { stem: "NeonTripleMarquee", slug: "undefined", component: c96 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "OutroGroupPhotoLaunch", slug: "undefined", component: c97 as unknown as React.ComponentType<Record<string, unknown>>, duration: d97, durationSource: "export" },
  { stem: "UiStripAwayOutro", slug: "undefined", component: c98 as unknown as React.ComponentType<Record<string, unknown>>, duration: 14, durationSource: "inline" },
  { stem: "IconFlipBloomLogo", slug: "undefined", component: c99 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "InputMorphsIntoLogo", slug: "undefined", component: c100 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "BeatCutAccelerando", slug: "undefined", component: c101 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "PaparazziFlash", slug: "undefined", component: c102 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "BeatStepListThemeCycle", slug: "undefined", component: c103 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "DominoCascade", slug: "undefined", component: c104 as unknown as React.ComponentType<Record<string, unknown>>, duration: 12, durationSource: "inline" },
  { stem: "DropBlackoutSlam", slug: "undefined", component: c105 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "WrightTripleCut", slug: "undefined", component: c106 as unknown as React.ComponentType<Record<string, unknown>>, duration: 25, durationSource: "inline" },
  { stem: "ComicPanelSplit", slug: "undefined", component: c107 as unknown as React.ComponentType<Record<string, unknown>>, duration: 45, durationSource: "inline" },
  { stem: "FlipGridReflow", slug: "undefined", component: c108 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "GridFlashMosaic", slug: "undefined", component: c109 as unknown as React.ComponentType<Record<string, unknown>>, duration: 14, durationSource: "inline" },
  { stem: "QuadSplitParallelScenes", slug: "undefined", component: c110 as unknown as React.ComponentType<Record<string, unknown>>, duration: d110, durationSource: "export" },
  { stem: "JumpCutPunchIn", slug: "undefined", component: c111 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "StrobeBlackFrames", slug: "undefined", component: c112 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SakugaTimingShift", slug: "undefined", component: c113 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SmearMultiples", slug: "undefined", component: c114 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SpectrumMorphUi", slug: "undefined", component: c115 as unknown as React.ComponentType<Record<string, unknown>>, duration: 8, durationSource: "inline" },
  { stem: "FreezeAnnotateReal", slug: "undefined", component: c116 as unknown as React.ComponentType<Record<string, unknown>>, duration: d116, durationSource: "export" },
  { stem: "SpeedRampReal", slug: "undefined", component: c117 as unknown as React.ComponentType<Record<string, unknown>>, duration: d117, durationSource: "export" },
  { stem: "CardFootageCadence", slug: "undefined", component: c118 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SmashCut", slug: "undefined", component: c119 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TrailerBumper", slug: "undefined", component: c120 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "BottomPushStackWipe", slug: "undefined", component: c121 as unknown as React.ComponentType<Record<string, unknown>>, duration: 30, durationSource: "inline" },
  { stem: "BubbleSwarmTakeover", slug: "undefined", component: c122 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CardFlipReveal", slug: "undefined", component: c123 as unknown as React.ComponentType<Record<string, unknown>>, duration: 18, durationSource: "inline" },
  { stem: "CardFlockTumble", slug: "undefined", component: c124 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CircleMatchIris", slug: "undefined", component: c125 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "ColorBlockStepWipe", slug: "undefined", component: c126 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CubeNavigation", slug: "undefined", component: c127 as unknown as React.ComponentType<Record<string, unknown>>, duration: d127, durationSource: "export" },
  { stem: "GradientTransition", slug: "undefined", component: c128 as unknown as React.ComponentType<Record<string, unknown>>, duration: d128, durationSource: "export" },
  { stem: "LineCarryTransition", slug: "undefined", component: c129 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "MosaicReframe", slug: "undefined", component: c130 as unknown as React.ComponentType<Record<string, unknown>>, duration: d130, durationSource: "export" },
  { stem: "BarnDoorSplit", slug: "undefined", component: c131 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CubeRotate", slug: "undefined", component: c132 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "PaperPlaneMessenger", slug: "undefined", component: c133 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "InkBleedReveal", slug: "undefined", component: c134 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "BlackCardTransition", slug: "undefined", component: c135 as unknown as React.ComponentType<Record<string, unknown>>, duration: d135, durationSource: "export" },
  { stem: "DarkTunnelTransition", slug: "undefined", component: c136 as unknown as React.ComponentType<Record<string, unknown>>, duration: d136, durationSource: "export" },
  { stem: "FocusHandoffTransition", slug: "undefined", component: c137 as unknown as React.ComponentType<Record<string, unknown>>, duration: d137, durationSource: "export" },
  { stem: "MaskWipeReal", slug: "undefined", component: c138 as unknown as React.ComponentType<Record<string, unknown>>, duration: d138, durationSource: "export" },
  { stem: "PortalWipeV2", slug: "undefined", component: c139 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "WhipBrakeReal", slug: "undefined", component: c140 as unknown as React.ComponentType<Record<string, unknown>>, duration: d140, durationSource: "export" },
  { stem: "WhipPanReal", slug: "undefined", component: c141 as unknown as React.ComponentType<Record<string, unknown>>, duration: d141, durationSource: "export" },
  { stem: "GlitchDisplace", slug: "undefined", component: c142 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "InvisibleCut", slug: "undefined", component: c143 as unknown as React.ComponentType<Record<string, unknown>>, duration: 54, durationSource: "inline" },
  { stem: "LightLeakBurn", slug: "undefined", component: c144 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "VersusSlam", slug: "undefined", component: c145 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "LetterformZoom", slug: "undefined", component: c146 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SharedElementMorph", slug: "undefined", component: c147 as unknown as React.ComponentType<Record<string, unknown>>, duration: 60, durationSource: "inline" },
  { stem: "WhiteFlashLogoSimplifyCut", slug: "undefined", component: c148 as unknown as React.ComponentType<Record<string, unknown>>, duration: d148, durationSource: "export" },
  { stem: "BlindsSlice", slug: "undefined", component: c149 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "ClockWipe", slug: "undefined", component: c150 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "BlurSlide", slug: "undefined", component: c151 as unknown as React.ComponentType<Record<string, unknown>>, duration: d151, durationSource: "export" },
  { stem: "BraceExpand", slug: "undefined", component: c152 as unknown as React.ComponentType<Record<string, unknown>>, duration: d152, durationSource: "export" },
  { stem: "BrandInkOpen", slug: "undefined", component: c153 as unknown as React.ComponentType<Record<string, unknown>>, duration: d153, durationSource: "export" },
  { stem: "CelFlashStomp", slug: "undefined", component: c154 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "CountdownArcScatter", slug: "undefined", component: c155 as unknown as React.ComponentType<Record<string, unknown>>, duration: d155, durationSource: "export" },
  { stem: "FlyingWords", slug: "undefined", component: c156 as unknown as React.ComponentType<Record<string, unknown>>, duration: d156, durationSource: "export" },
  { stem: "GlitchCycle", slug: "undefined", component: c157 as unknown as React.ComponentType<Record<string, unknown>>, duration: d157, durationSource: "export" },
  { stem: "GradientWordSweep", slug: "undefined", component: c158 as unknown as React.ComponentType<Record<string, unknown>>, duration: 30, durationSource: "inline" },
  { stem: "LeadWordZoomAssemble", slug: "undefined", component: c159 as unknown as React.ComponentType<Record<string, unknown>>, duration: d159, durationSource: "export" },
  { stem: "MarkerUnderlineTitle", slug: "undefined", component: c160 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "OutlineWordFill", slug: "undefined", component: c161 as unknown as React.ComponentType<Record<string, unknown>>, duration: d161, durationSource: "export" },
  { stem: "PaperTitleCard", slug: "undefined", component: c162 as unknown as React.ComponentType<Record<string, unknown>>, duration: d162, durationSource: "export" },
  { stem: "PillChipSlotCycleHandled", slug: "undefined", component: c163 as unknown as React.ComponentType<Record<string, unknown>>, duration: d163, durationSource: "export" },
  { stem: "PillSlotCycle", slug: "undefined", component: c164 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "Scramble", slug: "undefined", component: c165 as unknown as React.ComponentType<Record<string, unknown>>, duration: d165, durationSource: "export" },
  { stem: "SplitFlapFlip", slug: "undefined", component: c166 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TextColumnConverge", slug: "undefined", component: c167 as unknown as React.ComponentType<Record<string, unknown>>, duration: 36, durationSource: "inline" },
  { stem: "TitleDemoteToLabel", slug: "undefined", component: c168 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "LetterformDriftAssembly", slug: "undefined", component: c169 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SplitTextStagger", slug: "undefined", component: c170 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TextOnPath", slug: "undefined", component: c171 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TrackingExpandReveal", slug: "undefined", component: c172 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "LetterDropPhysics", slug: "undefined", component: c173 as unknown as React.ComponentType<Record<string, unknown>>, duration: 6, durationSource: "inline" },
  { stem: "ScrambleDecode", slug: "undefined", component: c174 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "FontWeightPump", slug: "undefined", component: c175 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "KaraokeFillSync", slug: "undefined", component: c176 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TerminalTypewriter", slug: "undefined", component: c177 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TypewriterErrorRetype", slug: "undefined", component: c178 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "TypingCodeBlock", slug: "undefined", component: c179 as unknown as React.ComponentType<Record<string, unknown>>, duration: d179, durationSource: "export" },
  { stem: "VerticalWordRollBlurCycle", slug: "undefined", component: c180 as unknown as React.ComponentType<Record<string, unknown>>, duration: d180, durationSource: "export" },
  { stem: "WordRelayFilmstrip", slug: "undefined", component: c181 as unknown as React.ComponentType<Record<string, unknown>>, duration: 16, durationSource: "inline" },
  { stem: "WordRelayGeometry", slug: "undefined", component: c182 as unknown as React.ComponentType<Record<string, unknown>>, duration: d182, durationSource: "export" },
  { stem: "AvatarBracketCarousel", slug: "undefined", component: c183 as unknown as React.ComponentType<Record<string, unknown>>, duration: d183, durationSource: "export" },
  { stem: "BezierSourceConvergeMerge", slug: "undefined", component: c184 as unknown as React.ComponentType<Record<string, unknown>>, duration: d184, durationSource: "export" },
  { stem: "CardStack", slug: "undefined", component: c185 as unknown as React.ComponentType<Record<string, unknown>>, duration: d185, durationSource: "export" },
  { stem: "Carousel3D", slug: "undefined", component: c186 as unknown as React.ComponentType<Record<string, unknown>>, duration: d186, durationSource: "export" },
  { stem: "ClonerDepthEcho", slug: "undefined", component: c187 as unknown as React.ComponentType<Record<string, unknown>>, duration: 10, durationSource: "inline" },
  { stem: "DeckDealFlyin", slug: "undefined", component: c188 as unknown as React.ComponentType<Record<string, unknown>>, duration: d188, durationSource: "export" },
  { stem: "DocParkLeftPillDeal", slug: "undefined", component: c189 as unknown as React.ComponentType<Record<string, unknown>>, duration: d189, durationSource: "export" },
  { stem: "DocumentTypewriterReveal", slug: "undefined", component: c190 as unknown as React.ComponentType<Record<string, unknown>>, duration: d190, durationSource: "export" },
  { stem: "DrawSvgTrace", slug: "undefined", component: c191 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "AxialStretch", slug: "undefined", component: c192 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "ContactShadowLift", slug: "undefined", component: c193 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "FloatingGlossyLabelPills", slug: "undefined", component: c194 as unknown as React.ComponentType<Record<string, unknown>>, duration: d194, durationSource: "export" },
  { stem: "IntegrationHubMap", slug: "undefined", component: c195 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "ListReveal", slug: "undefined", component: c196 as unknown as React.ComponentType<Record<string, unknown>>, duration: d196, durationSource: "export" },
  { stem: "ListStackPress", slug: "undefined", component: c197 as unknown as React.ComponentType<Record<string, unknown>>, duration: d197, durationSource: "export" },
  { stem: "MorphFromPrimitive", slug: "undefined", component: c198 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "NeonFrameForerun", slug: "undefined", component: c199 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "NeonFrameForerunOrbit", slug: "undefined", component: c200 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "PageWaterfallWall", slug: "undefined", component: c201 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "MaskingTapeSlap", slug: "undefined", component: c202 as unknown as React.ComponentType<Record<string, unknown>>, duration: 38, durationSource: "inline" },
  { stem: "PopupBookRise", slug: "undefined", component: c203 as unknown as React.ComponentType<Record<string, unknown>>, duration: 34, durationSource: "inline" },
  { stem: "PlatformHingeRise", slug: "undefined", component: c204 as unknown as React.ComponentType<Record<string, unknown>>, duration: d204, durationSource: "export" },
  { stem: "ProductCardProgressiveAssemble", slug: "undefined", component: c205 as unknown as React.ComponentType<Record<string, unknown>>, duration: d205, durationSource: "export" },
  { stem: "RadialWave", slug: "undefined", component: c206 as unknown as React.ComponentType<Record<string, unknown>>, duration: d206, durationSource: "export" },
  { stem: "ResearchCardStackScroll", slug: "undefined", component: c207 as unknown as React.ComponentType<Record<string, unknown>>, duration: d207, durationSource: "export" },
  { stem: "RowEmbed", slug: "undefined", component: c208 as unknown as React.ComponentType<Record<string, unknown>>, duration: d208, durationSource: "export" },
  { stem: "RunwayGroundSkim", slug: "undefined", component: c209 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SkeletonReveal", slug: "undefined", component: c210 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "SvgShapeMorph", slug: "undefined", component: c211 as unknown as React.ComponentType<Record<string, unknown>>, duration: d211, durationSource: "export" },
  { stem: "ValueStaggerGradient", slug: "undefined", component: c212 as unknown as React.ComponentType<Record<string, unknown>>, duration: d212, durationSource: "export" },
  { stem: "BentoLightUp", slug: "undefined", component: c213 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "GridWaveFlip", slug: "undefined", component: c214 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
  { stem: "WireframeDrawOn", slug: "undefined", component: c215 as unknown as React.ComponentType<Record<string, unknown>>, duration: 150, durationSource: "default" },
];
